-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_dorm
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `adminId` int NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`adminId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','111','二组','男','123'),(2,'mayiting','mayiting','马仪婷','女','456'),(3,'luyu','luyu','陆雨','女','789'),(4,'hexin','hexin','何欣','女','123');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `living`
--

DROP TABLE IF EXISTS `living`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `living` (
  `livingId` int NOT NULL AUTO_INCREMENT,
  `livingBuildId` int DEFAULT NULL,
  `livingName` varchar(20) DEFAULT NULL,
  `livingType` varchar(20) DEFAULT NULL,
  `livingNumber` int DEFAULT NULL,
  `livingTel` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`livingId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `living`
--

LOCK TABLES `living` WRITE;
/*!40000 ALTER TABLE `living` DISABLE KEYS */;
INSERT INTO `living` VALUES (1,1,'101','六人间',6,'110'),(2,2,'202','六人间',6,'440'),(3,3,'303','六人间',5,'550'),(4,4,'404','六人间',4,'550'),(5,5,'505','六人间',6,'440'),(6,6,'606','六人间',5,'431');
/*!40000 ALTER TABLE `living` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `livingbuild`
--

DROP TABLE IF EXISTS `livingbuild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `livingbuild` (
  `livingBuildId` int NOT NULL AUTO_INCREMENT,
  `livingBuildName` varchar(20) DEFAULT NULL,
  `livingBuildDetail` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`livingBuildId`)
) ENGINE=InnoDB AUTO_INCREMENT=5530 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livingbuild`
--

LOCK TABLES `livingbuild` WRITE;
/*!40000 ALTER TABLE `livingbuild` DISABLE KEYS */;
INSERT INTO `livingbuild` VALUES (1,'博学院1号楼','女生宿舍'),(2,'博学院2号楼','女生宿舍'),(3,'博学院3号楼','女生宿舍'),(4,'集美院4号楼','男生宿舍'),(5,'集美院5号楼','男生宿舍'),(6,'集美院6号楼','男生宿舍');
/*!40000 ALTER TABLE `livingbuild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `livingmanager`
--

DROP TABLE IF EXISTS `livingmanager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `livingmanager` (
  `livingManId` int NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `livingBuildId` int DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`livingManId`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livingmanager`
--

LOCK TABLES `livingmanager` WRITE;
/*!40000 ALTER TABLE `livingmanager` DISABLE KEYS */;
INSERT INTO `livingmanager` VALUES (1,'dorm1','dorm1',1,'管理员1','女','1234567'),(2,'dorm2','dorm2',2,'管理员2','女','2345'),(3,'dorm3','dorm3',3,'管理员3','女','3456'),(4,'dorm4','dorm4',4,'管理员4','男','4567'),(5,'dorm5','dorm5',5,'管理员5','男','4567'),(6,'dorm6','dorm6',6,'管理员6','男','6789');
/*!40000 ALTER TABLE `livingmanager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `record`
--

DROP TABLE IF EXISTS `record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record` (
  `recordId` int NOT NULL AUTO_INCREMENT,
  `studentNumber` varchar(20) DEFAULT NULL,
  `studentName` varchar(30) DEFAULT NULL,
  `livingBuildId` int DEFAULT NULL,
  `livingName` varchar(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `detail` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`recordId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record`
--

LOCK TABLES `record` WRITE;
/*!40000 ALTER TABLE `record` DISABLE KEYS */;
INSERT INTO `record` VALUES (1,'21','陆雨',3,'303','2020-06-29','迟到'),(19,'23','马仪婷',1,'101','2020-07-02','迟到'),(20,'12','何欣',2,'202','2020-06-30','迟到');
/*!40000 ALTER TABLE `record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `studentId` int NOT NULL AUTO_INCREMENT,
  `stuNum` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `livingBuildId` int DEFAULT NULL,
  `livingName` varchar(11) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`studentId`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,'01','czy','蔡卓宜',4,'404','男','123'),(2,'02','ccj','陈成杰',5,'505','男','123'),(12,'12','hx','何欣',2,'202','女','9876'),(21,'21','ly','陆雨',3,'303','女','3456'),(23,'23','myt','马仪婷',1,'101','女','4567'),(32,'32','wjq','魏建奇',6,'606','男','1234');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-03 20:46:50
