package com.two.dao;

import java.sql.Connection;
import java.util.List;

import com.two.bean.LivingBuild;
import com.two.bean.Record;

public interface RecordDao {
	List<Record>  ListStudentRecord(Connection con, Record s_record, String studentNumber)throws Exception; 
	
	public List<Record> recordList(Connection co, Record record) throws Exception;

	List<LivingBuild> livingBuildList(Connection co);
	
	int recordDelete(Connection con, String recordId);
}
