package com.two.dao;

import java.sql.Connection;
import java.util.List;

import com.two.bean.LivingBuild;
import com.two.bean.LivingManager;
import com.two.bean.PageBean;

public interface LivingBuildDao {
	public String livingBuildName(Connection con, int livingBuildId);

	public List<LivingBuild> livingBuildList(Connection con, PageBean pageBean,LivingBuild livingBuild);

	public int livingBuildCount(Connection con, LivingBuild livingBuild);

	public int livingBuildUpdate(Connection con, LivingBuild livingBuild);

	public int livingBuildAdd(Connection con, LivingBuild livingBuild);

	public LivingBuild livingBuildShow(Connection con, String livingBuildId);

	public List<LivingManager> livingManWithBuildId(Connection con,
			String livingBuildId);

	public List<LivingManager> livingManWithoutBuild(Connection con);

	public boolean existManOrDormWithId(Connection con, String livingBuildId);

	public int livingBuildDelete(Connection con, String livingBuildId);

	public int managerUpdateWithId(Connection con, String livingBuildId,
			String livingManagerId);
}
