package com.two.dao;

import java.sql.Connection;

import com.two.bean.Admin;
import com.two.bean.LivingManager;
import com.two.bean.Student;

public interface LoginDao {

	Object AdminLogin(Connection conn, Admin admin);

	Object LivingManagerLogin(Connection conn, LivingManager liv);

	Object StudentLogin(Connection conn, Student student);

}
