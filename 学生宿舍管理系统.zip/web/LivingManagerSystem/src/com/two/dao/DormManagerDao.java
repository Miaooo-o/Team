package com.two.dao;

import java.util.List;

import com.two.bean.Record;
import com.two.bean.Student;

public interface DormManagerDao {

	//根据楼id获取楼的名字
	String getBuildName(int buidId);

	//根据楼id获取学生
	List<Student> studentListWithBuild(int buildId);

	//根据楼查询缺勤记录
	List<Record> recordListWithBuild(int buildId);

	//修改密码
	void passwordUpdate(int livingManagerId, String newPassword);

	//获取缺勤记录
	Record recordShow(String recordId);

	//根据学号和楼号查询学生信息
	Student dormManagerDaogetNameById(String studentNumber, int buildId);

	//修改缺勤记录
	int recordUpdate(Record record);

	//添加缺勤记录
	int recordAdd(Record record);

	//删除缺勤记录
	void recordDelete(String recordId);

	//按姓名查找
	List<Student> studentSearch(String searchType,int buildId, String studentText);

	//缺勤记录查询
	List<Record> studentRecordSearch(String searchType, int buildId, String studentText);

}
