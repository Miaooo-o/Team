package com.two.dao;

import java.sql.Connection;
import java.util.List;

import com.two.bean.LivingBuild;
import com.two.bean.Student;

public interface StudentDao {

	List<Student> studentList(Connection con, Student student);

	List<LivingBuild> livingBuildList(Connection con);

	Student studentShow(Connection con, String studentId);

	int studentUpdate(Connection con, Student student);

	boolean haveNameByNumber(Connection con, String stuNumber);

	int studentAdd(Connection con, Student student);

	int studentDelete(Connection con, String studentId);


}
