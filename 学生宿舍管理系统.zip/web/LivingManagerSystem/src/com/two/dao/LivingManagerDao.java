package com.two.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.two.bean.LivingManager;
import com.two.bean.PageBean;

public interface LivingManagerDao {

	List<LivingManager> livingManagerList(Connection con, PageBean pageBean,LivingManager livingManager);

	int livingManagerCount(LivingManager livingManager);

	LivingManager dormManagerShow(Connection con, int dormManagerId);

	int livingManagerUpdate(Connection con, LivingManager livingManager);

	Boolean haveManagerUser(Connection con, String userName);

	int livingManagerAdd(Connection con, LivingManager livingManager);

	void livingManagerDelete(Connection con, int parseInt);

}
