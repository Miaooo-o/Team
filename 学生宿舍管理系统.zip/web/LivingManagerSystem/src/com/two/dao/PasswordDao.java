package com.two.dao;

import java.sql.Connection;

public interface PasswordDao {
	public int adminUpdateDao(Connection con, int adminId, String password)throws Exception;
	public int managerUpdateDao(Connection con, int managerId, String password)throws Exception;
	public int studentUpdateDao(Connection con, int studentId, String password)throws Exception;
}
