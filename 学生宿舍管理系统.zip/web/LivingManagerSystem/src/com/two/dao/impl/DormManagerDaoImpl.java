package com.two.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.two.bean.Record;
import com.two.bean.Student;
import com.two.dao.DormManagerDao;
import com.two.util.DbUtil;

public class DormManagerDaoImpl implements DormManagerDao{

	//根据楼id获取楼的名字
	public String getBuildName(int buidId) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = DbUtil.getCon();
			String sql = "select * from livingBuild where livingBuildId=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, buidId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString("LivingBuildName");
			}
		} catch (Exception e) {
			
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
		return null;
	}

	//根据楼id获取学生
	public List<Student> studentListWithBuild(int buildId) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Student> studentList = new ArrayList<Student>();
		String sql = "select * from student where livingBuildId=?";
		try {
			con = DbUtil.getCon();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, buildId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Student student=new Student();
				student.setStudentId(rs.getInt("studentId"));
				int livingBuildId;
				livingBuildId = rs.getInt("livingBuildId");
				student.setLivingBuildId(livingBuildId);
				student.setLivingBuildName(getBuildName(buildId));
				student.setLivingName(rs.getString("livingName"));
				student.setName(rs.getString("name"));
				student.setSex(rs.getString("sex"));
				student.setStuNumber(rs.getString("stuNum"));
				student.setTel(rs.getString("tel"));
				student.setPassword(rs.getString("password"));
				studentList.add(student);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
		
		return studentList;
	}

	@Override
	public List<Record> recordListWithBuild(int buildId) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Record> recordList = new ArrayList<Record>();
		String sql = "select * from record where livingBuildId=?";
		try {
			con = DbUtil.getCon();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, buildId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Record record=new Record();
				record.setRecordId(rs.getInt("recordId"));
				record.setStudentNumber(rs.getString("studentNumber"));
				record.setStudentName(rs.getString("studentName"));
				int dormBuildId = rs.getInt("livingBuildId");
				record.setLivingBuildId(dormBuildId);
				record.setLivingBuildName(getBuildName(buildId));
				record.setLivingName(rs.getString("livingName"));
				record.setDate(rs.getString("date"));
				record.setDetail(rs.getString("detail"));
				recordList.add(record);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
		
		return recordList;
	}

	//修改密码
	public void passwordUpdate(int livingManagerId, String newPassword) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt=null;
		try {
			con = DbUtil.getCon();
			String sql = "update livingmanager set password=? where livingManId=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, newPassword);
			pstmt.setInt(2, livingManagerId);
			pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	//获取缺勤记录
	public Record recordShow(String recordId) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Record record = new Record();
		String sql = "select * from record where recordId=?";
		try {
			con = DbUtil.getCon();
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, recordId);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				record.setRecordId(rs.getInt("recordId"));
				record.setStudentNumber(rs.getString("studentNumber"));
				record.setStudentName(rs.getString("studentName"));
				int livingBuildId = rs.getInt("livingBuildId");
				record.setLivingBuildId(livingBuildId);
				record.setLivingBuildName(getBuildName(livingBuildId));
				record.setLivingName(rs.getString("livingName"));
				record.setDate(rs.getString("date"));
				record.setDetail(rs.getString("detail"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
		
		return record;
	}

	//根据学号和楼号查询学生信息
	public Student dormManagerDaogetNameById(String studentNumber, int buildId) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		Student student = new Student();
		try {
			con = DbUtil.getCon();
			String sql = "select * from student where stuNum=? and livingBuildId=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, studentNumber);
			pstmt.setInt(2, buildId);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				student.setName(rs.getString("name"));
				student.setLivingBuildId(rs.getInt("livingBuildId"));
				student.setLivingName(rs.getString("livingName"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
		return student;
	}

	//修改缺勤记录
	public int recordUpdate(Record record) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		Student student = new Student();
		try {
			con = DbUtil.getCon();
			String sql = "update record set studentNumber=?,studentName=?,livingBuildId=?,livingName=?,detail=? where recordId=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, record.getStudentNumber());
			pstmt.setString(2, record.getStudentName());
			pstmt.setInt(3, record.getLivingBuildId());
			pstmt.setString(4, record.getLivingName());
			pstmt.setString(5, record.getDetail());
			pstmt.setInt(6, record.getRecordId());
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
		return 0;
		
	}

	//添加缺勤记录
	public int recordAdd(Record record) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		Student student = new Student();
		try {
			con = DbUtil.getCon();
		String sql = "insert into record values(null,?,?,?,?,?,?)";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, record.getStudentNumber());
		pstmt.setString(2, record.getStudentName());
		pstmt.setInt(3, record.getLivingBuildId());
		pstmt.setString(4, record.getLivingName());
		pstmt.setString(5, record.getDate());
		pstmt.setString(6, record.getDetail());
		return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
		return 0;
	}

	//删除缺勤记录
	public void recordDelete(String recordId) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		Student student = new Student();
		try {
			con = DbUtil.getCon();
		String sql = "delete from record where recordId=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, recordId);
		pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
	}

	//查找
	public List<Student> studentSearch(String searchType,int buildId, String studentText) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Student> studentList = new ArrayList<Student>();
		String sql = null;
		if("name".equals(searchType)) {
			sql="select * from student where livingBuildId=? and name=?";
		}
		
		if("number".equals(searchType)) {
			sql="select * from student where livingBuildId=? and stuNum=?";
		}
		
		if("dorm".equals(searchType)) {
			sql="select * from student where livingBuildId=? and livingName=?";
		}
		try {
			con = DbUtil.getCon();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, buildId);
			pstmt.setString(2, studentText);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Student student=new Student();
				student.setStudentId(rs.getInt("studentId"));
				int livingBuildId;
				livingBuildId = rs.getInt("livingBuildId");
				student.setLivingBuildId(livingBuildId);
				student.setLivingBuildName(getBuildName(buildId));
				student.setLivingName(rs.getString("livingName"));
				student.setName(rs.getString("name"));
				student.setSex(rs.getString("sex"));
				student.setStuNumber(rs.getString("stuNum"));
				student.setTel(rs.getString("tel"));
				student.setPassword(rs.getString("password"));
				studentList.add(student);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
		
		return studentList;
	}

	//缺勤记录查询
	public List<Record> studentRecordSearch(String searchType, int buildId, String studentText) {
		DbUtil dbutil = new DbUtil();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		List<Record> recordList = new ArrayList<Record>();
		if("name".equals(searchType)) {
			sql = "select * from record where livingBuildId=? and studentName=?";
		}
		if("number".equals(searchType)) {
			sql = "select * from record where livingBuildId=? and studentNumber=?";
		}
		
		if("dorm".equals(searchType)) {
			sql = "select * from record where livingBuildId=? and livingName=?";
		}
		try {
			con = DbUtil.getCon();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, buildId);
			pstmt.setString(2, studentText);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Record record=new Record();
				record.setRecordId(rs.getInt("recordId"));
				record.setStudentNumber(rs.getString("studentNumber"));
				record.setStudentName(rs.getString("studentName"));
				int dormBuildId = rs.getInt("livingBuildId");
				record.setLivingBuildId(dormBuildId);
				record.setLivingBuildName(getBuildName(buildId));
				record.setLivingName(rs.getString("livingName"));
				record.setDate(rs.getString("date"));
				record.setDetail(rs.getString("detail"));
				recordList.add(record);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.release(con,pstmt,rs);
		}
		
		return recordList;
	}

}
