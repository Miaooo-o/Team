package com.two.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.two.util.DbUtil;
import com.two.util.StringUtil;
import com.two.bean.LivingBuild;
import com.two.bean.Record;
import com.two.dao.LivingBuildDao;
import com.two.dao.RecordDao;


public class RecordDaoImpl implements RecordDao{

	private LivingBuildDao livingBuildDao = new LivingBuilDaoImpl();
	@Override
	public List<Record> ListStudentRecord(Connection con, Record s_record, String studentNumber) {
			List<Record> recordList = new ArrayList<Record>();
			Connection c = DbUtil.getConnection();
			StringBuffer sb = new StringBuffer("select * from record t1 ");
			if(StringUtil.isNotEmpty(studentNumber)) {
				sb.append(" and t1.studentNumber ="+studentNumber);
			} 
			if(StringUtil.isNotEmpty(s_record.getStartDate())){
				sb.append(" and TO_DAYS(t1.date)>=TO_DAYS('"+s_record.getStartDate()+"')");
			}
			if(StringUtil.isNotEmpty(s_record.getEndDate())){
				sb.append(" and TO_DAYS(t1.date)<=TO_DAYS('"+s_record.getEndDate()+"')");
			}
			PreparedStatement pstmt =null;
			ResultSet rs = null;
			System.out.println("toString"+sb.toString());
			try {
				pstmt = c.prepareStatement(sb.toString().replaceFirst("and", "where"));
				System.out.println(pstmt);
				rs =pstmt.executeQuery();
				while(rs.next()) {
					Record record=new Record();
					record.setRecordId(rs.getInt("recordId"));
					record.setStudentNumber(rs.getString("studentNumber"));
					record.setStudentName(rs.getString("studentName"));
					int livingBuildId = rs.getInt("livingBuildId");
					record.setLivingBuildId(livingBuildId);
//					record.setLivingBuildName(rs.getString("livingBuildName"));
					record.setLivingName(rs.getString("livingName"));
					record.setDate(rs.getString("date"));
					record.setDetail(rs.getString("detail"));
					recordList.add(record);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					DbUtil.closeCon(c);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				DbUtil.release(con, pstmt, rs);
			}
			
			return recordList;
	}
	public List<Record> recordList(Connection co, Record record){
		List<Record> recordList = new ArrayList<Record>();
		System.out.println(recordList);
		StringBuffer sb = new StringBuffer("select * from record t1  left join livingbuild b1 on t1.livingBuildId = b1.livingBuildId");
		System.out.println(sb.toString());
		if(StringUtil.isNotEmpty(record.getStudentNumber())) {
			sb.append(" and t1.studentNumber like '%"+record.getStudentNumber()+"%'");
		} else if(StringUtil.isNotEmpty(record.getStudentName())) {
			sb.append(" and t1.studentName like '%"+record.getStudentName()+"%'");
		}
		if(record.getLivingBuildId()!=0) {
			sb.append(" and t1.livingBuildId="+record.getLivingBuildId());
		}
		if(StringUtil.isNotEmpty(record.getDate())) {
			sb.append(" and t1.date="+record.getDate());
		}
		System.out.println(sb.toString());
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try {
			pstmt=co.prepareStatement(sb.toString().replaceFirst("and", "where"));
			System.out.println("sbis"+sb);
			rs = pstmt.executeQuery();
			System.out.println("rs"+rs);
			while(rs.next()) {
				Record record1=new Record();
				record1.setRecordId(rs.getInt("recordId"));
				System.out.println("rs.getInt('recordId')"+rs.getInt("recordId"));
				record1.setStudentNumber(rs.getString("studentNumber"));
				record1.setStudentName(rs.getString("studentName"));
				int dormBuildId = rs.getInt("livingBuildId");
				record1.setLivingBuildId(dormBuildId);
				record1.setLivingBuildName(rs.getString("livingBuildName"));
				record1.setLivingName(rs.getString("livingName"));
				record1.setDate(rs.getString("date"));
				record1.setDetail(rs.getString("livingBuilddetail"));
				recordList.add(record1);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(recordList+"******");
		return recordList;
	}
	public List<LivingBuild> livingBuildList(Connection co) {
		List<LivingBuild> dormBuildList = new ArrayList<LivingBuild>();
		String sql = "select * from livingBuild t1   left join record b1 on t1.livingBuildId = b1.livingBuildId";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try {
			pstmt = co.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				LivingBuild dormBuild=new LivingBuild();
				dormBuild.setLivingBuildId(rs.getInt("livingBuildId"));
				dormBuild.setLivingBuildName(rs.getString("livingBuildName"));
				dormBuild.setLivingBuilddetail(rs.getString("livingBuildDetail"));
				dormBuildList.add(dormBuild);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.release(co, pstmt, rs);
		}
		
		return dormBuildList;
	}
	public int recordDelete(Connection con, String recordId) {
		String sql = "delete from record where recordId=?";
		PreparedStatement pstmt=null;
		int i =0;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, recordId);
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return i;
	}
	
	

}
