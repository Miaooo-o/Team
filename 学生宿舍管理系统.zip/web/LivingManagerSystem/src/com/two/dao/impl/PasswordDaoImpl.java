package com.two.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.two.dao.PasswordDao;

public class PasswordDaoImpl implements PasswordDao{

	@Override
	public int adminUpdateDao(Connection con, int adminId, String password) throws Exception {
		String sql = "update admin set password=? where adminId=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, password);
		pstmt.setInt(2, adminId);
		return pstmt.executeUpdate();
	}

	@Override
	public int managerUpdateDao(Connection con, int managerId, String password) throws Exception{
		String sql = "update livingmanager set password=? where livingManId=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, password);
		pstmt.setInt(2, managerId);
		return pstmt.executeUpdate();
	}

	@Override
	public int studentUpdateDao(Connection con, int studentId, String password) throws Exception{
		String sql = "update student set password=? where studentId=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, password);
		pstmt.setInt(2, studentId);
		return pstmt.executeUpdate();
	}
}
