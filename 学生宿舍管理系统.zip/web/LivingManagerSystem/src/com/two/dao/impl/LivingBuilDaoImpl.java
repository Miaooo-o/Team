package com.two.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.two.bean.LivingBuild;
import com.two.bean.LivingManager;
import com.two.bean.PageBean;
import com.two.dao.LivingBuildDao;
import com.two.util.DbUtil;
import com.two.util.StringUtil;

public class LivingBuilDaoImpl implements LivingBuildDao{

	@Override
	public String livingBuildName(Connection con, int livingBuildId) {
		Connection c = DbUtil.getConnection();
		String sql = "select * from livingBuild where livingBuildId=?";
		PreparedStatement pstmt=null;
		ResultSet rs =null;
		String str= null;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setInt(1, livingBuildId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				str= rs.getString("livingBuildName");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt, rs);
		}
		
		return str;
	}

	@Override
	public List<LivingBuild> livingBuildList(Connection con, PageBean pageBean,LivingBuild livingBuild) {
		List<LivingBuild> dormBuildList = new ArrayList<LivingBuild>();
		Connection c = DbUtil.getConnection();
		StringBuffer sb = new StringBuffer("select * from livingBuild t1 left join livingbuild b1 on t1.livingBuildId = b1.livingBuildId");
		if(StringUtil.isNotEmpty(livingBuild.getLivingBuildName())) {
			sb.append(" where t1.livingBuildName like '%"+livingBuild.getLivingBuildName()+"%'");
		}
		if(pageBean != null) {
			sb.append(" limit "+pageBean.getStart()+","+pageBean.getPageSize());
		}
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try {
			pstmt = c.prepareStatement(sb.toString());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				LivingBuild livingBuild1=new LivingBuild();
				livingBuild1.setLivingBuildId(rs.getInt("livingBuildId"));
				livingBuild1.setLivingBuildName(rs.getString("livingBuildName"));
				livingBuild1.setLivingBuilddetail(rs.getString("livingBuildDetail"));
				dormBuildList.add(livingBuild1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt, rs);
		}
		System.out.println(dormBuildList);
		return dormBuildList;
	}

	@Override
	public int livingBuildCount(Connection con, LivingBuild livingBuild) {
		Connection c = DbUtil.getConnection();
		StringBuffer sb = new StringBuffer("select count(*) as total from livingBuild t1");
		if(StringUtil.isNotEmpty(livingBuild.getLivingBuildName())) {
			sb.append(" where t1.livingBuildName like '%"+livingBuild.getLivingBuildName()+"%'");
		}
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		int i =0;
		try {
			pstmt = c.prepareStatement(sb.toString());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return i=rs.getInt("total");
			} else {
				return i=0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt, rs);
		}
		
		return i;
	}

	@Override
	public int livingBuildUpdate(Connection con, LivingBuild livingBuild) {
		String sql = "update livingBuild set livingBuildName=?,livingBuilddetail=? where livingBuildId=?";
		PreparedStatement pstmt=null;
		Connection c = DbUtil.getConnection();
		int i =0;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setString(1, livingBuild.getLivingBuildName());
			pstmt.setString(2, livingBuild.getLivingBuilddetail());
			pstmt.setInt(3, livingBuild.getLivingBuildId());
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt);
		}
		
		return i;
	}

	@Override
	public int livingBuildAdd(Connection con, LivingBuild livingBuild) {
		String sql = "insert into livingBuild values(null,?,?)";
		Connection c = DbUtil.getConnection();
		PreparedStatement pstmt=null;
		int i =0;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setString(1, livingBuild.getLivingBuildName());
			pstmt.setString(2, livingBuild.getLivingBuilddetail());
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt);
		}
		
		return i;
	}

	@Override
	public LivingBuild livingBuildShow(Connection con, String livingBuildId) {
		Connection c = DbUtil.getConnection();
		int id = Integer.parseInt(livingBuildId);
		String sql = "select * from livingBuild t1 where t1.livingBuildId=?";
		PreparedStatement pstmt=null;
		LivingBuild livingBuild1 = null;
		ResultSet rs= null;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			livingBuild1 = new LivingBuild();
			if(rs.next()) {
				livingBuild1.setLivingBuildId(rs.getInt("livingBuildId"));
				livingBuild1.setLivingBuildName(rs.getString("livingBuildName"));
				livingBuild1.setLivingBuilddetail(rs.getString("livingBuildDetail"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt, rs);
		}
		
		return livingBuild1;
	}

	@Override
	public List<LivingManager> livingManWithBuildId(Connection con,
			String livingBuildId) {
		Connection c = DbUtil.getConnection();
		int livingId = Integer.parseInt(livingBuildId);
		List<LivingManager> livingManagerList = new ArrayList<LivingManager>();
		String sql = "select *from livingmanager where livingBuildId=?";
		PreparedStatement pstmt=null;
		ResultSet rs =null;
		try {
			pstmt = c.prepareStatement(sql);
			System.out.println(livingBuildId);
			pstmt.setInt(1, livingId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				LivingManager livingManager=new LivingManager();
				livingManager.setLivingBuildId(rs.getInt("livingBuildId"));
				livingManager.setLivingManagerId(rs.getInt("livingManId"));
				livingManager.setName(rs.getString("name"));
				livingManager.setUserName(rs.getString("userName"));
				livingManager.setSex(rs.getString("sex"));
				livingManager.setTel(rs.getString("tel"));
				livingManagerList.add(livingManager);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt, rs);
		}
		System.out.println(livingManagerList);
		return livingManagerList;
	}

	@Override
	public List<LivingManager> livingManWithoutBuild(Connection con) {
		List<LivingManager> livingManagerList = new ArrayList<LivingManager>();
		Connection c = DbUtil.getConnection();
		String sql = "SELECT * FROM livingManager WHERE livingBuildId IS NULL OR livingBuildId=0";
		PreparedStatement pstmt = null;
		ResultSet rs =null;
		try {
			pstmt = c.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				LivingManager livingManager=new LivingManager();
				livingManager.setLivingBuildId(rs.getInt("livingBuildId"));
				livingManager.setLivingManagerId(rs.getInt("livingManId"));
				livingManager.setName(rs.getString("name"));
				livingManager.setUserName(rs.getString("userName"));
				livingManager.setSex(rs.getString("sex"));
				livingManager.setTel(rs.getString("tel"));
				livingManagerList.add(livingManager);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt, rs);
		}
		
		return livingManagerList;
	}

	@Override
	//判断宿舍楼中有没有学生入住
	public boolean existManOrDormWithId(Connection con, String livingBuildId) {
		Connection c = DbUtil.getConnection();
		boolean isExist = false;
		//先查查楼栋有没有管理员
		String sql = "select *from livingManager where livingBuildId=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setString(1, livingBuildId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				isExist = true;
			} else {
				isExist = false;
			}
			//然后再查查有没有学生住
			String sql1="select * from livingBuild t1,living t2 where t1.livingBuildId=t2.livingBuildId and t1.livingBuildId=?";
			PreparedStatement p=con.prepareStatement(sql1);
			p.setString(1, livingBuildId);
			ResultSet r = pstmt.executeQuery();
			if(r.next()) {
				return isExist;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt, rs);
		}
		return isExist;
	}

	@Override
	public int livingBuildDelete(Connection con, String livingBuildId) {
		Connection c = DbUtil.getConnection();
		String sql = "delete from livingBuild where livingBuildId=?";
		PreparedStatement pstmt=null;
		int i =0;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setString(1, livingBuildId);
			i = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt);
		}
		
		return i;
	}
//添加宿舍管理员
	@Override
	public int managerUpdateWithId(Connection con,String livingManagerId, String livingBuildId) {
		Connection c = DbUtil.getConnection();
		String sql = "update livingmanager set livingBuildId=? where livingManId=?";
		System.out.println("livingManagerId是多少"+livingManagerId+livingBuildId);
		
		PreparedStatement pstmt=null;
		int i =0;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(livingBuildId));
			pstmt.setInt(2, Integer.parseInt(livingManagerId));
			pstmt.executeUpdate();
			System.out.println("i是等于"+i);
			i=Integer.parseInt(livingBuildId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt);
		}
		
		return i;
		
	}

}
