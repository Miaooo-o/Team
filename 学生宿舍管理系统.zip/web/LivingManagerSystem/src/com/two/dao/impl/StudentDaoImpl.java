package com.two.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.two.bean.LivingBuild;
import com.two.bean.Student;
import com.two.dao.LivingBuildDao;
import com.two.dao.StudentDao;
import com.two.util.DbUtil;
import com.two.util.StringUtil;

public class StudentDaoImpl implements StudentDao {
	

	@Override
	public List<Student> studentList(Connection con, Student student) {
		List<Student> studentList = new ArrayList<Student>();
		StringBuffer sb = new StringBuffer("select * from student t1  left join livingbuild b1 on t1.livingBuildId = b1.livingBuildId");
		//搜索时，根据搜索类型进行相关查询
		if(StringUtil.isNotEmpty(student.getName())) {
			sb.append(" and t1.name like '%"+student.getName()+"%'");
		} else if(StringUtil.isNotEmpty(student.getStuNumber())) {
			sb.append(" and t1.stuNum like '%"+student.getStuNumber()+"%'");
		} else if(StringUtil.isNotEmpty(student.getLivingName())) {
			sb.append(" and t1.livingName like '%"+student.getLivingName()+"%'");
		}
		if(student.getLivingBuildId()!=0) {
			sb.append(" and t1.livingBuildId="+student.getLivingBuildId());
		}
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Student student1=new Student();
				student1.setStudentId(rs.getInt("studentId"));
				int livingBuildId = rs.getInt("livingBuildId");
				student1.setLivingBuildId(livingBuildId);
				student1.setLivingBuildName(rs.getString("livingBuildName"));
				student1.setLivingName(rs.getString("livingName"));
				student1.setName(rs.getString("name"));
				student1.setSex(rs.getString("sex"));
				student1.setStuNumber(rs.getString("stuNum"));
				student1.setTel(rs.getString("tel"));
				student1.setPassword(rs.getString("password"));
				studentList.add(student1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt, rs);
		}
		
		return studentList;
	}

	@Override
	public List<LivingBuild> livingBuildList(Connection con) {
		List<LivingBuild> dormBuildList = new ArrayList<>();
		Connection c = DbUtil.getConnection();
		String sql = "select * from livingBuild t1";
		PreparedStatement pstmt=null;
		ResultSet rs =null;
		try {
			pstmt = c.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				LivingBuild dormBuild=new LivingBuild();
				dormBuild.setLivingBuildId(rs.getInt("livingBuildId"));
				dormBuild.setLivingBuildName(rs.getString("livingBuildName"));
				dormBuild.setLivingBuilddetail(rs.getString("livingBuildDetail"));
				dormBuildList.add(dormBuild);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt, rs);
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return dormBuildList;
	}

	@Override
	public Student studentShow(Connection con, String studentId) {
		Connection c = DbUtil.getConnection();
		String sql = "select * from student t1   left join livingbuild b1 on t1.livingBuildId = b1.livingBuildId where t1.studentId=?";
		PreparedStatement pstmt= null;
		ResultSet rs=null;
		Student student = null;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setString(1, studentId);
			rs=pstmt.executeQuery();
			student = new Student();
			if(rs.next()) {
				student.setStudentId(rs.getInt("studentId"));
				int livingBuildId = rs.getInt("livingBuildId");
				student.setLivingBuildId(livingBuildId);
				student.setLivingBuildName(rs.getString("livingBuildName"));
				student.setLivingName(rs.getString("livingName"));
				student.setName(rs.getString("name"));
				student.setSex(rs.getString("sex"));
				student.setStuNumber(rs.getString("stuNum"));
				student.setTel(rs.getString("tel"));
				student.setPassword(rs.getString("password"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt, rs);
		}
		
		return student;
	}

	@Override
	public int studentUpdate(Connection con, Student student) {
		String sql = "update student set stuNum=?,password=?,name=?,livingBuildId=?,livingName=?,sex=?,tel=? where studentId=?";
		PreparedStatement pstmt= null;
		int i =0;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, student.getStuNumber());
			pstmt.setString(2, student.getPassword());
			pstmt.setString(3, student.getName());
			pstmt.setInt(4, student.getLivingBuildId());
			pstmt.setString(5, student.getLivingName());
			pstmt.setString(6, student.getSex());
			pstmt.setString(7, student.getTel());
			pstmt.setInt(8, student.getStudentId());
			i =pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt);
		}
		
		return i;
	}

	@Override
	public boolean haveNameByNumber(Connection con, String stuNumber) {
		String sql = "select * from student t1   left join livingbuild b1 on t1.livingBuildId = b1.livingBuildId where t1.stuNum=?";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, stuNumber);
			rs=pstmt.executeQuery();
			Student student = new Student();
			if(rs.next()) {
				student.setName(rs.getString("name"));
				student.setLivingBuildId(rs.getInt("livingBuildId"));
				student.setLivingName(rs.getString("livingName"));
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt, rs);
		}
		
		return false;
	}

	@Override
	public int studentAdd(Connection con, Student student) {
		Connection c =DbUtil.getConnection();
		String sql = "insert into student values(null,?,?,?,?,?,?,?)";
		PreparedStatement pstmt= null;
		int i = 0;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setString(1, student.getStuNumber());
			pstmt.setString(2, student.getPassword());
			pstmt.setString(3, student.getName());
			pstmt.setInt(4, student.getLivingBuildId());
			pstmt.setString(5, student.getLivingName());
			pstmt.setString(6, student.getSex());
			pstmt.setString(7, student.getTel());
			i = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt);
		}
		
		return i;
	}

	@Override
	public int studentDelete(Connection con, String studentId) {
		String sql = "delete from student where studentId=?";
		PreparedStatement pstmt=null;
		int i =0;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, studentId);
			i =pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt);
		}
		
		return i;
	}

}
