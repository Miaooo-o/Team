package com.two.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.two.bean.LivingManager;
import com.two.bean.PageBean;
import com.two.dao.LivingBuildDao;
import com.two.dao.LivingManagerDao;
import com.two.util.DbUtil;
import com.two.util.StringUtil;

public class LivingManagerDaoImpl implements LivingManagerDao {
	
	LivingBuildDao livingBuildDao =   new LivingBuilDaoImpl();
//获得宿舍管理员人员的数据
	@Override
	public List<LivingManager> livingManagerList(Connection con,PageBean pageBean, LivingManager livingManager) {
		List<LivingManager> livingManagerList = new ArrayList<LivingManager>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer("SELECT * FROM livingManager t1 left join livingbuild b1 on t1.livingBuildId = b1.livingBuildId");
		//判断是用户名查询还是姓名查询
		if(StringUtil.isNotEmpty(livingManager.getName())) {
			sb.append(" where t1.name like '%"+livingManager.getName()+"%'");
		} else if(StringUtil.isNotEmpty(livingManager.getUserName())) {
			sb.append(" where t1.userName like '%"+livingManager.getUserName()+"%'");
		}
		//添加分页
		if(pageBean != null) {
			sb.append(" limit "+pageBean.getStart()+","+pageBean.getPageSize());
		}

		try {
			//
			pstmt = con.prepareStatement(sb.toString());
			System.out.println(sb.toString());
			rs = pstmt.executeQuery();
			//讲所查数据放入实体类对象中
			while(rs.next()) {
				LivingManager dormManager=new LivingManager();
				dormManager.setLivingManagerId(rs.getInt("livingManId"));
				int livingBuildId = rs.getInt("livingBuildId");
				dormManager.setLivingBuildId(livingBuildId);
				
				dormManager.setLivingBuildName(rs.getString("livingBuildName"));
				
				dormManager.setName(rs.getString("name"));
				dormManager.setSex(rs.getString("sex"));
				dormManager.setUserName(rs.getString("userName"));
				dormManager.setTel(rs.getString("tel"));
				dormManager.setPassword(rs.getString("password"));
				//遍历完一次讲实体类放入一次list集合中
				livingManagerList.add(dormManager);
				System.out.println("^^^^^"+dormManager);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.release(con,pstmt,rs);
		}
		System.out.println("daoimpl"+livingManagerList);
		return livingManagerList;
	}

	@Override//获取宿舍管理员总数
	public int livingManagerCount(LivingManager livingManager){
		Connection con = null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		StringBuffer sb = new StringBuffer("select count(*) as total from livingManager t1");
		int total = 0;
		//判断是姓名还是username
		if(StringUtil.isNotEmpty(livingManager.getName())) {
			sb.append(" where t1.name like '%"+livingManager.getName()+"%'");
		} else if(StringUtil.isNotEmpty(livingManager.getUserName())) {
			sb.append(" where t1.userName like '%"+livingManager.getUserName()+"%'");
		}
		
		try {
			con = DbUtil.getConnection();
			pstmt = con.prepareStatement(sb.toString());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return total = rs.getInt("total");
			} else {
				return total =0;
			}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt, rs);
		}
		System.out.println(total);
		return total;
	}

	@Override
	public LivingManager dormManagerShow(Connection con, int livingManagerId) {
		String sql = "select * from livingManager t1 where t1.livingManId=?";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		LivingManager livingManager = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, livingManagerId);
			rs=pstmt.executeQuery();
			livingManager = new LivingManager();
			if(rs.next()) {
				livingManager.setLivingManagerId(rs.getInt("livingManId"));
				livingManager.setLivingBuildId(rs.getInt("livingBuildId"));
				livingManager.setName(rs.getString("name"));
				livingManager.setSex(rs.getString("sex"));
				livingManager.setUserName(rs.getString("userName"));
				livingManager.setTel(rs.getString("tel"));
				livingManager.setPassword(rs.getString("password"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt,rs);
		}
		
		
		return livingManager;
	}

	@Override//修改
	public int livingManagerUpdate(Connection con, LivingManager livingManager) {
		String sql = "update livingManager set userName=?,password=?,name=?,sex=?,tel=? where livingManId=?";
		PreparedStatement pstmt=null;
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, livingManager.getUserName());
			pstmt.setString(2, livingManager.getPassword());
			pstmt.setString(3, livingManager.getName());
			pstmt.setString(4, livingManager.getSex());
			pstmt.setString(5, livingManager.getTel());
			pstmt.setInt(6, livingManager.getLivingManagerId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int i=0;
		try {
			i = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt);
		}
		return i;
	}

	@Override
	public Boolean haveManagerUser(Connection con, String userName) {
		String sql = "select * from livingManager t1 where t1.userName=?";
		PreparedStatement pstmt=null;
		ResultSet rs= null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userName);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt);
		}
		
		return false;
	}

	@Override//添加宿舍管理员
	public int livingManagerAdd(Connection con, LivingManager livingManager) {
		Connection c = DbUtil.getConnection();
		String sql = "insert into livingManager values(null,?,?,null,?,?,?)";
		PreparedStatement pstmt=null;
		try {
			pstmt = c.prepareStatement(sql);
			pstmt.setString(1, livingManager.getUserName());
			pstmt.setString(2, livingManager.getPassword());
			pstmt.setString(3, livingManager.getName());
			pstmt.setString(4, livingManager.getSex());
			pstmt.setString(5, livingManager.getTel());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int i=0;
		try {
			i = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				DbUtil.closeCon(c);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DbUtil.release(con, pstmt);
		}
		return i;
	}

	@Override
	public void livingManagerDelete(Connection con, int parseInt) {
		String sql = "delete from livingManager where livingManId=?";
		PreparedStatement pstmt=null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, parseInt);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.release(con, pstmt);
		}
		
	}

}
