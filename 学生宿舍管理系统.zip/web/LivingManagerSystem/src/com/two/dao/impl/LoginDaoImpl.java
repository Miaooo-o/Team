package com.two.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.two.bean.Admin;
import com.two.bean.LivingManager;
import com.two.bean.Student;
import com.two.dao.LivingBuildDao;
import com.two.dao.LoginDao;
import com.two.util.DbUtil;

public class LoginDaoImpl implements LoginDao {

	@Override
	
	public Object AdminLogin(Connection conn, Admin admin) {
		Admin resultAdmin = null;
		String sql = "select * from admin where userName=? and password=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, admin.getUserName());
			pstmt.setString(2, admin.getPassword());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				resultAdmin = new Admin();
				resultAdmin.setAdminId(rs.getInt("adminId"));
				resultAdmin.setUserName(rs.getString("userName"));
				resultAdmin.setPassword(rs.getString("password"));
				resultAdmin.setName(rs.getString("name"));
				resultAdmin.setSex(rs.getString("sex"));
				resultAdmin.setTel(rs.getString("tel"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
		     DbUtil.release(conn, pstmt, rs);
		}
		
		return resultAdmin;
	}

	@Override
	public Object LivingManagerLogin(Connection conn, LivingManager liv) {
		LivingManager resultManager = null;
		String sql = "select * from livingmanager where userName=? and password=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, liv.getUserName());
			pstmt.setString(2, liv.getPassword());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				resultManager = new LivingManager();
				resultManager.setLivingManagerId(rs.getInt("livingManId"));
				resultManager.setUserName(rs.getString("userName"));
				resultManager.setPassword(rs.getString("password"));
				resultManager.setLivingBuildId(rs.getInt("livingBuildId"));
				resultManager.setName(rs.getString("name"));
				resultManager.setSex(rs.getString("sex"));
				resultManager.setTel(rs.getString("tel"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
		     DbUtil.release(conn, pstmt, rs);
		}
		
		
		return resultManager;
	}

	@Override
	public Object StudentLogin(Connection conn, Student student) {
		LivingBuildDao living = new LivingBuilDaoImpl();
		Student resultStudent = null;
		String sql = "select * from student where stuNum=? and password=?";
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, student.getStuNumber());
			pstmt.setString(2, student.getPassword());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				resultStudent = new Student();
				resultStudent.setStudentId(rs.getInt("studentId"));
				resultStudent.setStuNumber(rs.getString("stuNum"));
				resultStudent.setPassword(rs.getString("password"));
				int livingBuildId = rs.getInt("livingBuildId");
				resultStudent.setLivingBuildId(livingBuildId);
				resultStudent.setLivingBuildName(living.livingBuildName(conn, livingBuildId));
				resultStudent.setLivingName(rs.getString("livingName"));
				resultStudent.setName(rs.getString("name"));
				resultStudent.setSex(rs.getString("sex"));
				resultStudent.setTel(rs.getString("tel"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		     DbUtil.release(conn, pstmt, rs);
		}
		
		return resultStudent;
	}

}
