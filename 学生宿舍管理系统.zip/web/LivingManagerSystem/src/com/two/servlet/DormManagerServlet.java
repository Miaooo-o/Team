package com.two.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.two.bean.LivingManager;
import com.two.bean.Record;
import com.two.bean.Student;
import com.two.service.DormManagerService;
import com.two.service.impl.DormManagerServiceImpl;
import com.two.util.StringUtil;


@WebServlet("/dormManager")
public class DormManagerServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//设置请求编码格式
		request.setCharacterEncoding("utf-8");
		String action = request.getParameter("action");
		String servlet = request.getParameter("servlet");
		//获取当前用户
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
	
		//获取服务层对象
		DormManagerService dormManagerService = new DormManagerServiceImpl();
		/******************空白页************************************/
		if("blank".equals(servlet)) {
			request.setAttribute("mainPage", "dormManager/blank.jsp");
			request.getRequestDispatcher("mainManager.jsp").forward(request, response);
		}
		
		/******************学生查看模块************************************/
		if("student".equals(servlet)) {
			System.out.println("学生模块");
			if("list".equals(action)) {
				if("livingManager".equals(currentUserType)) {
					//获取当前登录用户
					LivingManager manager = (LivingManager)(session.getAttribute("currentUser"));
					System.out.println(manager);
					//获取楼id
					int buildId = manager.getLivingBuildId();
					//获取楼的名字
					String buildName = dormManagerService.getBuildName(buildId);
					//获取对应楼学生列表
					List<Student> studentList = dormManagerService.studentListWithBuild(buildId);
					System.out.println(studentList);
					request.setAttribute("dormBuildName", buildName);
					request.setAttribute("studentList", studentList);
					request.setAttribute("mainPage", "dormManager/student.jsp");
					request.getRequestDispatcher("mainManager.jsp").forward(request, response);
				}
			}
			//查找
			if("search".equals(action)) {
				//获取搜索框内容
				String studentText = request.getParameter("s_studentText");
				//搜索类型
				String searchType = request.getParameter("searchType");
				//获取当前登录用户
				LivingManager manager = (LivingManager)(session.getAttribute("currentUser"));
				//获取楼id
				int buildId = manager.getLivingBuildId();
				//获取楼的名字
				String buildName = dormManagerService.getBuildName(buildId);
				
				if(StringUtil.isNotEmpty(studentText)) {
					if("name".equals(searchType)) {
						//查找用户
						List<Student> studentList = dormManagerService.studentSearch(searchType,buildId,studentText);
						System.out.println(studentList);
						request.setAttribute("dormBuildName", buildName);
						request.setAttribute("studentList", studentList);
						request.setAttribute("mainPage", "dormManager/student.jsp");
						request.getRequestDispatcher("mainManager.jsp").forward(request, response);
					} else if("number".equals(searchType)) {
						//查找学号
						List<Student> studentList = dormManagerService.studentSearch(searchType,buildId,studentText);
						System.out.println(studentList);
						request.setAttribute("dormBuildName", buildName);
						request.setAttribute("studentList", studentList);
						request.setAttribute("mainPage", "dormManager/student.jsp");
						request.getRequestDispatcher("mainManager.jsp").forward(request, response);
					} else if("dorm".equals(searchType)) {
						//查找寝室
						List<Student> studentList = dormManagerService.studentSearch(searchType,buildId,studentText);
						System.out.println(studentList);
						request.setAttribute("dormBuildName", buildName);
						request.setAttribute("studentList", studentList);
						request.setAttribute("mainPage", "dormManager/student.jsp");
						request.getRequestDispatcher("mainManager.jsp").forward(request, response);
					}
					session.setAttribute("s_studentText", studentText);
					session.setAttribute("searchType", searchType);
				}else {
					//搜索内容为空
					//清除搜索框
					session.removeAttribute("s_studentText");
					//清除搜索类型
					session.removeAttribute("searchType");
					request.getRequestDispatcher("dormManager?servlet=student&&action=list").forward(request, response);
				}
				
			}
						
		}
		
		/******************缺勤模块************************************/
		if("record".equals(servlet)) {
			if("list".equals(action)) {
				//获取当前登录用户
				LivingManager manager = (LivingManager)(session.getAttribute("currentUser"));
				//获取楼id
				int buildId = manager.getLivingBuildId();
				//获取楼的名字
				String buildName = dormManagerService.getBuildName(buildId);
				//获取对应楼的缺勤记录
				List<Record> recordList = dormManagerService.recordListWithBuild(buildId);
				System.out.println(recordList);
				request.setAttribute("dormBuildName", buildName);
				request.setAttribute("recordList", recordList);
				request.setAttribute("mainPage", "dormManager/record.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			} 
			//添加缺勤记录
			if("preSave".equals(action)) {
				//添加缺勤记录
				String recordId = request.getParameter("recordId");
				String studentNumber = request.getParameter("studentNumber");
				if (StringUtil.isNotEmpty(recordId)) {
					//获取缺勤记录
					Record record = dormManagerService.recordShow(recordId);
					request.setAttribute("record", record);
				} else {
					//获取系统时间
					Calendar rightNow = Calendar.getInstance();       
					SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");   
					String sysDatetime = fmt.format(rightNow.getTime());
					request.setAttribute("studentNumber", studentNumber);
					request.setAttribute("date", sysDatetime);
				}
				request.setAttribute("mainPage", "dormManager/recordSave.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			}
			
			//保存缺勤记录
			if("save".equals(action)) {
				//是否保存成功
				int saveNum = 0;
				//获取记录ID
				String recordId = request.getParameter("recordId");
				//获取学号
				String studentNumber = request.getParameter("studentNumber");
				//获取日期
				String date = request.getParameter("date");
				//获取备注
				String detail = request.getParameter("detail");
				Record record = new Record(studentNumber, date, detail); 
				//查询记录号是否为空
				if(StringUtil.isNotEmpty(recordId)) {
					if(Integer.parseInt(recordId)!=0) {
						record.setRecordId(Integer.parseInt(recordId));
					}
				}
				//获取当前登录用户
				LivingManager manager = (LivingManager)(session.getAttribute("currentUser"));
				//获取宿舍管理员管理的楼号
				int buildId = manager.getLivingBuildId();
				//根据学号和楼号查询学生信息
				Student student = dormManagerService.getNameById(studentNumber, buildId);
				if(student.getName() == null) {
					request.setAttribute("record", record);
					request.setAttribute("error", "学号不在您管理的宿舍楼内");
					request.setAttribute("mainPage", "dormManager/recordSave.jsp");
					request.getRequestDispatcher("mainManager.jsp").forward(request, response);
				} else {
					//添加数据到记录
					record.setLivingBuildId(student.getLivingBuildId());
					record.setStudentName(student.getName());
					record.setLivingName(student.getLivingName());
					//如果记录存在
					if(StringUtil.isNotEmpty(recordId) && Integer.parseInt(recordId)!=0) {
						//修改记录
						saveNum = dormManagerService.recordUpdate(record);
					} else {
						//添加记录
						saveNum = dormManagerService.recordAdd(record);
					}
					if(saveNum > 0) {
						request.getRequestDispatcher("dormManager?servlet=record&&action=list").forward(request, response);
					} else {
						request.setAttribute("record", record);
						request.setAttribute("error", "保存失败");
						request.setAttribute("mainPage", "dormManager/recordSave.jsp");
						request.getRequestDispatcher("mainManager.jsp").forward(request, response);
					}
				}
				
			}
			
			//删除缺勤记录
			if("delete".equals(action)) {
				String recordId = request.getParameter("recordId");
				dormManagerService.recordDelete(recordId);
				request.getRequestDispatcher("dormManager?servlet=record&&action=list").forward(request, response);
			}
			
			//搜索
			if("search".equals(action)) {
				//获取搜索框内容
				String studentText = request.getParameter("s_studentText");
				//搜索类型
				String searchType = request.getParameter("searchType");
				//获取当前登录用户
				LivingManager manager = (LivingManager)(session.getAttribute("currentUser"));
				//获取楼id
				int buildId = manager.getLivingBuildId();
				//获取楼的名字
				String buildName = dormManagerService.getBuildName(buildId);
				
				if(StringUtil.isNotEmpty(studentText)) {
					if("name".equals(searchType)) {
						//用户名查找
						//获取对应楼的缺勤记录
						List<Record> recordList = dormManagerService.studentRecordSearch(searchType,buildId,studentText);
						System.out.println(recordList);
						request.setAttribute("dormBuildName", buildName);
						request.setAttribute("recordList", recordList);
						request.setAttribute("mainPage", "dormManager/record.jsp");
						request.getRequestDispatcher("mainManager.jsp").forward(request, response);
					} else if("number".equals(searchType)) {
						//学号查找
						//获取对应楼的缺勤记录
						List<Record> recordList = dormManagerService.studentRecordSearch(searchType,buildId,studentText);
						System.out.println(recordList);
						request.setAttribute("dormBuildName", buildName);
						request.setAttribute("recordList", recordList);
						request.setAttribute("mainPage", "dormManager/record.jsp");
						request.getRequestDispatcher("mainManager.jsp").forward(request, response);
					} else if("dorm".equals(searchType)) {
						//寝室号查找
						//获取对应楼的缺勤记录
						List<Record> recordList = dormManagerService.studentRecordSearch(searchType,buildId,studentText);
						System.out.println(recordList);
						request.setAttribute("dormBuildName", buildName);
						request.setAttribute("recordList", recordList);
						request.setAttribute("mainPage", "dormManager/record.jsp");
						request.getRequestDispatcher("mainManager.jsp").forward(request, response);
					}
					session.setAttribute("s_studentText", studentText);
					session.setAttribute("searchType", searchType);
				}else {
					//搜索内容为空
					//清除搜索框
					session.removeAttribute("s_studentText");
					//清除搜索类型
					session.removeAttribute("searchType");
					request.getRequestDispatcher("dormManager?servlet=record&&action=list").forward(request, response);
				}
				
			}
			
		}
		
		/******************修改密码模块************************************/
		if("password".equals(servlet)) {
			System.out.println("修改密码模块");
			if("livingManager".equals((String)currentUserType)) {
				if("preChange".equals(action)) {
					//更新密码界面
					request.setAttribute("mainPage", "dormManager/passwordChange.jsp");
					request.getRequestDispatcher("mainManager.jsp").forward(request, response);
					return;
				} else if("change".equals(action)) {
					//修改密码
					//获取密码
					String oldPassword = request.getParameter("oldPassword");
					String newPassword = request.getParameter("newPassword");
					System.out.println(oldPassword);
					if("livingManager".equals((String)currentUserType)) {
						LivingManager manager = (LivingManager)(session.getAttribute("currentUser"));
						//判断老密码是否正确
						System.out.println(manager.getPassword());
						if(oldPassword.equals(manager.getPassword())) {
							//修改密码
							dormManagerService.passwordUpdate(manager.getLivingManagerId(), newPassword);
							System.out.println(manager.getLivingManagerId());
							manager.setPassword(newPassword);
							request.setAttribute("oldPassword", oldPassword);
							request.setAttribute("newPassword", newPassword);
							request.setAttribute("rPassword", newPassword);
							request.setAttribute("error", "修改成功 ");
							request.setAttribute("mainPage", "dormManager/passwordChange.jsp");
							request.getRequestDispatcher("mainManager.jsp").forward(request, response);
						} else {
							request.setAttribute("oldPassword", oldPassword);
							request.setAttribute("newPassword", newPassword);
							request.setAttribute("rPassword", newPassword);
							request.setAttribute("error", "原密码错误");
							request.setAttribute("mainPage", "dormManager/passwordChange.jsp");
							request.getRequestDispatcher("mainManager.jsp").forward(request, response);
						}
					return;
					}
				}
			} 
		}
	}	
}
