package com.two.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.two.bean.LivingManager;
import com.two.bean.PageBean;
import com.two.service.LivingManagerService;
import com.two.service.impl.LivingManagerServiceImpl;
import com.two.util.BottomPageUtil;
import com.two.util.DbUtil;
import com.two.util.PageUtil;
import com.two.util.StringUtil;

@WebServlet("/livingManager")
public class LivingManagerServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private LivingManagerService livingManagerService = new LivingManagerServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		//搜索框中输入的文本
		String livingManagerText = request.getParameter("livingManagerText");
		//搜索时选择的搜索方式
		String searchType = request.getParameter("searchType");
		//获取的当前页
		String page = request.getParameter("page");
		System.out.println(page);
		//获取action
		String action = request.getParameter("action");
		LivingManager livingManager = new LivingManager();

		//添加
		if("preSave".equals(action)){
			//通过此方法跳转至添加界面
			livingManagerPreSave(request, response);
			return;
			//添加数据
		} else if("save".equals(action)) {
			livingManagerSave(request, response);
			return;
			//判断是否是删除
		} else if("delete".equals(action)){
			livingManagerDelete(request, response);
			return;
			//判断是否是查看
		} else if("list".equals(action)) {
			//利用工具类判断这玩意儿是否不为空
			if(StringUtil.isNotEmpty(livingManagerText)) {
				if("name".equals(searchType)) {
					livingManager.setName(livingManagerText);
				} else if("userName".equals(searchType)) {
					livingManager.setUserName(livingManagerText);
				}
			}
			
			session.removeAttribute("livingManagerText");
			session.removeAttribute("searchType");
			request.setAttribute("livingManagerText",livingManagerText);
			request.setAttribute("searchType", searchType);

		} else if("search".equals(action)){
			//如果搜索框中有填写内容
			if (StringUtil.isNotEmpty(livingManagerText)) {
				if ("name".equals(searchType)) {
					livingManager.setName(livingManagerText);
				} else if ("userName".equals(searchType)) {
					livingManager.setUserName(livingManagerText);
				}
				session.setAttribute("searchType", searchType);
				session.setAttribute("livingManagerText", livingManagerText);
			} else {
				session.removeAttribute("livingManagerText");
				session.removeAttribute("searchType");
			}
		} else {
			if(StringUtil.isNotEmpty(livingManagerText)) {
				if("name".equals(searchType)) {
					livingManager.setName(livingManagerText);
				} else if("userName".equals(searchType)) {
					livingManager.setUserName(livingManagerText);
				}
				session.setAttribute("searchType", searchType);
				session.setAttribute("livingManagerText", livingManagerText);
			}
			if(StringUtil.isEmpty(livingManagerText)) {
				Object o1 = session.getAttribute("livingManagerText");
				Object o2 = session.getAttribute("searchType");
				if(o1!=null) {
					if("name".equals((String)o2)) {
						livingManager.setName((String)o1);
					} else if("userName".equals((String)o2)) {
						livingManager.setUserName((String)o1);
					}
				}
			}
		}  
        if (StringUtil.isEmpty(page)) {
			page = "1";
		}
   		Connection con = null;
   		//获取当前页和每页显示的数据    将数据存入实体类中
   		PageBean pageBean = new PageBean(Integer.parseInt(page), PageUtil.getValue());
   		request.setAttribute("pageSize", pageBean.getPageSize());
   		request.setAttribute("page", pageBean.getPage());
   		System.out.println(page+"----123124214");
   		try {
   			con=DbUtil.getConnection();
   			//通过pagebean，livingManager获取当前页所有的数据
   			List<LivingManager> livingManagerList = livingManagerService.livingManagerList(con, pageBean, livingManager);
   			System.out.println("sdjbdvali"+livingManagerList+pageBean);
   			//获取管理员总数
   			int total=livingManagerService.livingManagerCount(livingManager);
   			System.out.println(total);
   			//利用总数据，当前页，还有一页中的数据来创建获取前端页面翻页功能的html代码
   			String pageCode = BottomPageUtil.genPagation(total, Integer.parseInt(page), PageUtil.getValue());
   			System.out.println(pageCode);
   			request.setAttribute("pageCode", pageCode);
   			request.setAttribute("dormManagerList", livingManagerList);
   			request.setAttribute("mainPage", "admin/dormManager.jsp");
   			request.getRequestDispatcher("mainAdmin.jsp").forward(request,response);
   		} catch (Exception e) {
   			e.printStackTrace();
   		} finally {
   			try {
   				DbUtil.closeCon(con);
   			} catch (Exception e) {
   				e.printStackTrace();
   			}
   		}
		
	}

//删除操作
private void livingManagerDelete(HttpServletRequest request,
			HttpServletResponse response) {
	String livingManagerId = request.getParameter("dormManagerId");
	Connection con = null;
	try {
		con = DbUtil.getConnection();
		livingManagerService.livingManagerDelete(con, Integer.parseInt(livingManagerId));
		request.getRequestDispatcher("livingManager?action=list").forward(request, response);
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
			DbUtil.closeCon(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	}
//点击添加时，利用livingManagerPreSave跳转至添加页面
private void livingManagerPreSave(HttpServletRequest request,
		HttpServletResponse response)throws ServletException, IOException {
	//根据id修改宿舍管理员数据
	String livingManagerId = request.getParameter("livingManagerId");
	System.out.println("宿舍管理员id"+livingManagerId);
	//id不为空
	if(StringUtil.isNotEmpty(livingManagerId)) {
		Connection con = null;
		try {
			
			con = DbUtil.getConnection();
			//根据id来获取宿舍管理员的数据
			LivingManager dormManager = livingManagerService.dormManagerShow(con, Integer.parseInt(livingManagerId));
			System.out.println(dormManager);
			//将数据一起转发到jsp页面
			request.setAttribute("dormManager", dormManager);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	} 
	
	request.setAttribute("mainPage", "admin/dormManagerSave.jsp");
	request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
}
//添加宿舍管理员
    private void livingManagerSave(HttpServletRequest request,HttpServletResponse response){
	String livingManagerId = request.getParameter("dormManagerId");
	String userName = request.getParameter("userName");
	String password = request.getParameter("password");
	String name = request.getParameter("name");
	String sex = request.getParameter("sex");
	String tel = request.getParameter("tel");
	System.out.println("为u有覅完全被"+userName+livingManagerId);
	//将参数放入实体类中
	LivingManager livingManager = new LivingManager(userName, password, name, sex, tel);
	//判断id是否不为空
	if(StringUtil.isNotEmpty(livingManagerId)) {
		livingManager.setLivingManagerId(Integer.parseInt(livingManagerId));
	}
	Connection con = null;
	try {
		//创建链接
		con = DbUtil.getConnection();
		int saveNum = 0;
		
		//修改数据时，id不为空
		if(StringUtil.isNotEmpty(livingManagerId)) {
			saveNum = livingManagerService.livingManagerUpdate(con, livingManager);
		}else {
			//添加数据
			saveNum = livingManagerService.livingManagerAdd(con, livingManager);
			System.out.println(saveNum);
		}
		//添加成功（修改成功），跳转到宿舍管理员列表
		if(saveNum > 0) {
			request.getRequestDispatcher("livingManager?action=list").forward(request, response);
			//数据有误，添加失败
		} else {
			request.setAttribute("dormManager", livingManager);
			request.setAttribute("error", "有误，添加失败");
			//重新跳转至添加界面
			request.setAttribute("mainPage", "dormManager/dormManagerSave.jsp");
			request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
			DbUtil.closeCon(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

}