package com.two.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.two.bean.Admin;
import com.two.bean.LivingManager;
import com.two.bean.Student;
import com.two.service.LoginService;
import com.two.service.impl.LoginServiceImpl;
import com.two.util.CookieUtil;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private LoginService loginService = new LoginServiceImpl();
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		//获取登陆界面的数据
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		String remember = request.getParameter("remember");
		String userType = request.getParameter("userType");
		//根据登陆界面的数据来匹配数据库中的数据（通过面向对象特性，在业务层进行判断登录人员的类型）
		//Object接受所有类型
		Object object = loginService.login(userName, password, userType);
		switch (userType) {
		//再做判断，将object转换成登录人员的类型
		//如果是系统管理员
		case "admin":
			Admin currentAdmin = (Admin) object;
			//返回数据为空
			if(currentAdmin == null) {
				//为空则将错误信息反馈给登陆界面（请求转发，讲error直接返回到登陆界面）
				request.setAttribute("error", "当前用户账户或密码错误");
				request.getRequestDispatcher("login.jsp").forward(request, response);
				//不为空
			} else {
				//用户是否点击了记住我，如果点击了
				if("remember-me".equals(remember)) {
					//直接利用cookie将数据放入客户端存七天
					CookieUtil.rememberMe(userName, password, userType,response);
				} else {
					//如果没有点击，如果cookie中有相关人员的数据，直接删除客户端cookie
					CookieUtil.deleteCookie(userName, request, response);
				}
				//将当前数据保存在session域中，跳转至当前用户登陆界面
				session.setAttribute("currentUserType", "admin");
				session.setAttribute("currentUser", currentAdmin);
				request.setAttribute("mainPage", "admin/blank.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			}
			break;
        //如果是宿舍管理员
		case "dormManager":
			LivingManager Currentliving = (LivingManager) object;
			if(Currentliving == null) {
				request.setAttribute("error", "当前用户账户或密码错误");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			} else {
				if("remember-me".equals(remember)) {
					CookieUtil.rememberMe(userName, password, userType,response);
				} else {
					CookieUtil.deleteCookie(userName, request, response);
				}
				session.setAttribute("currentUserType", "livingManager");
				session.setAttribute("currentUser", Currentliving);
				request.setAttribute("mainPage", "dormManager/blank.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			}
			break;
		//如果是学生
		case "student":
			Student currentStudent = (Student) object;
			if(currentStudent == null) {
				request.setAttribute("error", "当前用户账户或密码错误");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			} else {
				if("remember-me".equals(remember)) {
					CookieUtil.rememberMe(userName, password, userType,response);
				} else {
					CookieUtil.deleteCookie(userName, request, response);
				}
				session.setAttribute("currentUserType", "student");
				session.setAttribute("currentUser", currentStudent);
				request.setAttribute("mainPage", "student/blank.jsp");
				request.getRequestDispatcher("mainStudent.jsp").forward(request, response);
			}
			break;
			
		}
	}
	}


