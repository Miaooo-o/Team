package com.two.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.two.bean.LivingBuild;
import com.two.bean.LivingManager;
import com.two.bean.PageBean;
import com.two.service.LivingBuildService;
import com.two.service.impl.LivingBuildServiceImpl;
import com.two.util.BottomPageUtil;
import com.two.util.DbUtil;
import com.two.util.PageUtil;
import com.two.util.StringUtil;

/**
 * Servlet implementation class LivingBuildServlet
 */
@WebServlet("/livingBuild")
public class LivingBuildServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private LivingBuildService livingBuildService = new LivingBuildServiceImpl();



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String livingBuildName = request.getParameter("s_dormBuildName");
		String page = request.getParameter("page");
		String action = request.getParameter("action");
		LivingBuild livingBuild = new LivingBuild();
		//修改
		if("preSave".equals(action)) {
			livingBuildPreSave(request, response);
			return;
		} else if("save".equals(action)){
			livingBuildSave(request, response);
			return;
		} else
			if("delete".equals(action)){
			livingBuildDelete(request, response);
			return;
		} else
			//管理员列表
			if("manager".equals(action)){
			livingBuildManager(request, response);
			return;
		} else
			//添加管理员
			if("addManager".equals(action)){
			livingBuildAddManager(request, response);
		} else if("move".equals(action)){
			managerMove(request, response);
		} else
			if("list".equals(action)) {
				//搜索
			if(StringUtil.isNotEmpty(livingBuildName)) {
				livingBuild.setLivingBuildName(livingBuildName);
			}
			session.removeAttribute("livingBuildName");
			request.setAttribute("livingBuildName", livingBuildName);
		}
			else if("search".equals(action)){
			if(StringUtil.isNotEmpty(livingBuildName)) {
				livingBuild.setLivingBuildName(livingBuildName);
				session.setAttribute("livingBuildName", livingBuildName);
			}else {
				session.removeAttribute("livingBuildName");
			}
		} 
			else {
			if(StringUtil.isNotEmpty(livingBuildName)) {
				livingBuild.setLivingBuildName(livingBuildName);
				session.setAttribute("livingBuildName", livingBuildName);
			}
			if(StringUtil.isEmpty(livingBuildName)) {
				Object o = session.getAttribute("livingBuildName");
				if(o!=null) {
					livingBuild.setLivingBuildName((String)o);
				}
			}
		}
		if(StringUtil.isEmpty(page)) {
			page="1";
		}
		Connection con = null;
		PageBean pageBean = new PageBean(Integer.parseInt(page),PageUtil.getValue() );
		request.setAttribute("pageSize", pageBean.getPageSize());
		request.setAttribute("page", pageBean.getPage());
		try {
			con=DbUtil.getConnection();
			List<LivingBuild> livingBuildList = livingBuildService.livingBuildList(con, pageBean, livingBuild);
			System.out.println("获取的宿舍楼"+livingBuildList);
			int total=livingBuildService.livingBuildCount(con, livingBuild);
			System.out.println(total);
			//翻页功能
			String pageCode = BottomPageUtil.getPagBuild(total, Integer.parseInt(page), PageUtil.getValue());
			request.setAttribute("pageCode", pageCode);
			request.setAttribute("livingBuildList", livingBuildList);
			request.setAttribute("mainPage", "admin/dormBuild.jsp");
			request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	private void managerMove(HttpServletRequest request,
			HttpServletResponse response) {
		String livingBuildId = request.getParameter("livingBuildId");
		String livingManagerId = request.getParameter("livingManagerId");
		Connection con = null;
		try {
			con = DbUtil.getConnection();
			livingBuildService.managerUpdateWithId(con, livingManagerId, "0");
			request.getRequestDispatcher("livingBuild?action=manager&livingBuildId="+livingBuildId).forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//给楼栋添加管理员
	private void livingBuildAddManager(HttpServletRequest request,
			HttpServletResponse response) {
		String livingBuildId = request.getParameter("livingBuildId");
		System.out.println("livingBuildId时"+livingBuildId);
		String livingManagerId = request.getParameter("livingManagerId");
		Connection con = null;
		try {
			con = DbUtil.getConnection();
			int i =livingBuildService.managerUpdateWithId(con, livingBuildId, livingManagerId);
			System.out.println("dskjhowlv"+livingBuildService.managerUpdateWithId(con, livingManagerId, livingManagerId));
			request.getRequestDispatcher("livingBuild?action=manager&livingBuildId="+i).forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//获取该栋楼的管理员
	private void livingBuildManager(HttpServletRequest request,
			HttpServletResponse response) {
		String livingBuildId = request.getParameter("livingBuildId");
		System.out.println(livingBuildId+"livingBuildIddekahgk");
		Connection con = null;
		try {
			con = DbUtil.getConnection();
			//获取该栋楼的宿舍管理员
			List<LivingManager> managerListWithId = livingBuildService.livingManWithBuildId(con, livingBuildId);
			System.out.println("获取的管理员"+managerListWithId);
			//获取可以添加的管理员，判断管理楼栋是否为空或者零
			List<LivingManager> managerListToSelect = livingBuildService.livingManWithoutBuild(con);
			System.out.println("______"+managerListToSelect);
			request.setAttribute("livingBuildId", livingBuildId);
			request.setAttribute("managerListWithId", managerListWithId);
			request.setAttribute("managerListToSelect", managerListToSelect);
			request.setAttribute("mainPage", "admin/selectManager.jsp");
			request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//删除操作
	private void livingBuildDelete(HttpServletRequest request,HttpServletResponse response) {
		String livingBuildId = request.getParameter("livingBuildId");
		Connection con = null;
		try {
			con = DbUtil.getConnection();
			//宿舍表和宿舍楼表进行联合查询，看看里面有没有宿舍还有联系电话等等，有的话就表明里面有人住，就删不了
			if(livingBuildService.existManOrDormWithId(con, livingBuildId)) {
				request.setAttribute("error", "该楼栋有人住哟老铁，删不了");
			} else {
				livingBuildService.livingBuildDelete(con, livingBuildId);
			}
			request.getRequestDispatcher("livingBuild?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void livingBuildSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String livingBuildId = request.getParameter("livingBuildId");
		String livingBuildName = request.getParameter("livingBuildName");
		String livingBuilddetail = request.getParameter("livingBuilddetail");
		System.out.println(livingBuildId);
		LivingBuild livingBuild = new LivingBuild(livingBuildName, livingBuilddetail);
		if(StringUtil.isNotEmpty(livingBuildId)) {
			livingBuild.setLivingBuildId(Integer.parseInt(livingBuildId));
		}
		Connection con = null;
		try {
			con = DbUtil.getConnection();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(livingBuildId)) {
				saveNum = livingBuildService.livingBuildUpdate(con, livingBuild);
			} else {
				saveNum = livingBuildService.livingBuildAdd(con, livingBuild);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("livingBuild?action=list").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
//修改管理员
	private void livingBuildPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String livingBuildId = request.getParameter("livingBuildId");
		if(StringUtil.isNotEmpty(livingBuildId)) {
			Connection con = null;
			try {
				con = DbUtil.getConnection();
				//根据id获取管理员
				LivingBuild livingBuild = livingBuildService.livingBuildShow(con, livingBuildId);
				System.out.println("-------"+livingBuild);
				request.setAttribute("livingBuild", livingBuild);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					DbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} 
		request.setAttribute("mainPage", "admin/dormBuildSave.jsp");
		request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
	}



}
