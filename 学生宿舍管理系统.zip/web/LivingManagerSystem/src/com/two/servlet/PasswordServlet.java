package com.two.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.two.bean.*;


import com.two.service.impl.PasswordServiceImpl;


@WebServlet("/password")
public class PasswordServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String action = request.getParameter("action");
		
		if("preChange".equals(action)) {
			passwordPreChange(request, response);
			return;
		} else if("change".equals(action)) {
			try {
				passwordChange(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
	}

	private void passwordChange(HttpServletRequest request,
			HttpServletResponse response)throws Exception {
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		String oldPassword = request.getParameter("oldPassword");
		String newPassword = request.getParameter("newPassword");

		PasswordServiceImpl passwordServiceImpl = new PasswordServiceImpl();
		
		if("admin".equals((String)currentUserType)) {
			Admin admin = (Admin)(session.getAttribute("currentUser"));
			if(oldPassword.equals(admin.getPassword())) {
				passwordServiceImpl.adminUpdate(admin.getAdminId(), newPassword);
				admin.setPassword(newPassword);
				request.setAttribute("oldPassword", oldPassword);
				request.setAttribute("newPassword", newPassword);
				request.setAttribute("rPassword", newPassword);
				request.setAttribute("error", "修改成功 ");
				request.setAttribute("mainPage", "admin/passwordChange.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			} else {
				request.setAttribute("oldPassword", oldPassword);
				request.setAttribute("newPassword", newPassword);
				request.setAttribute("rPassword", newPassword);
				request.setAttribute("error", "原密码错误");
				request.setAttribute("mainPage", "admin/passwordChange.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			}
		} else if("dormManager".equals((String)currentUserType)) {
			LivingManager manager = (LivingManager)(session.getAttribute("currentUser"));
			if(oldPassword.equals(manager.getPassword())) {
				passwordServiceImpl.managerUpdate( manager.getLivingManagerId(), newPassword);
				manager.setPassword(newPassword);
				request.setAttribute("oldPassword", oldPassword);
				request.setAttribute("newPassword", newPassword);
				request.setAttribute("rPassword", newPassword);
				request.setAttribute("error", "修改成功");
				request.setAttribute("mainPage", "dormManager/passwordChange.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			} else {
				request.setAttribute("oldPassword", oldPassword);
				request.setAttribute("newPassword", newPassword);
				request.setAttribute("rPassword", newPassword);
				request.setAttribute("error", "原密码错误");
				request.setAttribute("mainPage", "dormManager/passwordChange.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			}
		} else if("student".equals((String)currentUserType)) {
			Student student = (Student)(session.getAttribute("currentUser"));
			if(oldPassword.equals(student.getPassword())) {
				passwordServiceImpl.studentUpdate(student.getStudentId(), newPassword);
				student.setPassword(newPassword);
				request.setAttribute("oldPassword", oldPassword);
				request.setAttribute("newPassword", newPassword);
				request.setAttribute("rPassword", newPassword);
				request.setAttribute("error", "修改成功");
				request.setAttribute("mainPage", "student/passwordChange.jsp");
				request.getRequestDispatcher("mainStudent.jsp").forward(request, response);
			} else {
				request.setAttribute("oldPassword", oldPassword);
				request.setAttribute("newPassword", newPassword);
				request.setAttribute("rPassword", newPassword);
				request.setAttribute("error", "原密码错误");
				request.setAttribute("mainPage", "student/passwordChange.jsp");
				request.getRequestDispatcher("mainStudent.jsp").forward(request, response);
			}
		}
		
	}

	private void passwordPreChange(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		if("admin".equals((String)currentUserType)) {
			request.setAttribute("mainPage", "admin/passwordChange.jsp");
			request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
		} else if("dormManager".equals((String)currentUserType)) {
			request.setAttribute("mainPage", "dormManager/passwordChange.jsp");
			request.getRequestDispatcher("mainManager.jsp").forward(request, response);
		} else if("student".equals((String)currentUserType)) {
			request.setAttribute("mainPage", "student/passwordChange.jsp");
			request.getRequestDispatcher("mainStudent.jsp").forward(request, response);
		}
	}
}
