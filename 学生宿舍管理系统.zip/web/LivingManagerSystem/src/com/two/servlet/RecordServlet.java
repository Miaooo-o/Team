package com.two.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.two.dao.LivingBuildDao;
import com.two.dao.StudentDao;
import com.two.util.DbUtil;
import com.two.util.StringUtil;
import com.two.bean.Admin;
import com.two.bean.LivingManager;
import com.two.bean.Record;
import com.two.bean.Student;
import com.two.service.LoginService;
import com.two.service.RecordService;
import com.two.service.impl.LoginServiceImpl;
import com.two.service.impl.RecordServiceImpl;
import com.two.util.CookieUtil;
import com.two.service.impl.*;

@WebServlet("/record")
public class RecordServlet extends HttpServlet{

	/*创建数据库业务层对象*/
	RecordService recordSeriveceImpl = new RecordServiceImpl();
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		/*获取当前用户类型*/
		Object currentUserType = session.getAttribute("currentUserType");
		/*获取一些属性值*/
		String s_studentText = request.getParameter("s_studentText");
		String dormBuildId = request.getParameter("buildToSelect");
		String searchType = request.getParameter("searchType");
		String action = request.getParameter("action");
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		System.out.println(currentUserType+s_studentText+"qwertyuio"+action+startDate);
		Record record = new Record();
		Connection co= DbUtil.getConnection();
		
		if("preSave".equals(action)) {
			recordPreSave(request, response);
			return;
		} else if("save".equals(action)){
			recordSave(request, response);
			return;
		} else if("delete".equals(action)){
			recordDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(s_studentText)) {
				if("name".equals(searchType)) {
					record.setStudentName(s_studentText);
				} else if("number".equals(searchType)) {
					record.setStudentNumber(s_studentText);
				} else if("dorm".equals(searchType)) {
					record.setLivingName(s_studentText);
				}
			}
			if(StringUtil.isNotEmpty(dormBuildId)) {
				record.setLivingBuildId(Integer.parseInt(dormBuildId));
			}
			session.removeAttribute("s_studentText");
			session.removeAttribute("searchType");
			session.removeAttribute("buildToSelect");
			request.setAttribute("s_studentText", s_studentText);
			request.setAttribute("searchType", searchType);
			request.setAttribute("buildToSelect", dormBuildId);
		} else if("search".equals(action)){
			if(StringUtil.isNotEmpty(s_studentText)) {
				if("name".equals(searchType)) {
					record.setStudentName(s_studentText);
				} else if("number".equals(searchType)) {
					record.setStudentNumber(s_studentText);
				} else if("dorm".equals(searchType)) {
			        record.setLivingName(s_studentText);
				}
				session.setAttribute("s_studentText", s_studentText);
				session.setAttribute("searchType", searchType);
			} else {
				session.removeAttribute("s_studentText");
				session.removeAttribute("searchType");
			}
			
			if(StringUtil.isNotEmpty(dormBuildId)) {
				record.setLivingBuildId(Integer.parseInt(dormBuildId));
				session.setAttribute("buildToSelect", dormBuildId);
			}else {
				session.removeAttribute("buildToSelect");
			}
		} 

		if("admin".equals((String)currentUserType)) {
			System.out.println("currentUserType"+currentUserType);
			List<Record> recordList=null;
			try {
				recordList = recordSeriveceImpl.recordList(co, record);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("recordList"+recordList);
			request.setAttribute("dormBuildList", recordSeriveceImpl.livingBuildList(co));
			request.setAttribute("recordList", recordList);
			request.setAttribute("mainPage", "admin/record.jsp");
			request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
		}  else if("student".equals((String)currentUserType)) {
			/*获取学生对象*/
			Student student = (Student)(session.getAttribute("currentUser"));
			List<Record> recordList = null;
			try {
				/*从数据库获取记录列表*/
				recordList = recordSeriveceImpl.recordListWithNumber(record, student.getStuNumber());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			/*到record.jsp进行展示*/
			request.setAttribute("recordList", recordList);
			request.setAttribute("mainPage", "student/record.jsp");
			request.getRequestDispatcher("mainStudent.jsp").forward(request, response);
		}
		
	}

	private void recordDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String recordId = request.getParameter("recordId");
		Connection con = null;
		try {
			con = DbUtil.getCon();
			recordSeriveceImpl.recordDelete(con, recordId);
			request.getRequestDispatcher("record?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	private void recordSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String recordId = request.getParameter("recordId");
		String studentNumber = request.getParameter("studentNumber");
		String date = request.getParameter("date");
		String detail = request.getParameter("detail");
		Record record = new Record(studentNumber, date, detail); 
		if(StringUtil.isNotEmpty(recordId)) {
			if(Integer.parseInt(recordId)!=0) {
				record.setRecordId(Integer.parseInt(recordId));
			}
		}
		
	}

	private void recordPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String recordId = request.getParameter("recordId");
		String studentNumber = request.getParameter("studentNumber");
		
		request.setAttribute("mainPage", "dormManager/recordSave.jsp");
		request.getRequestDispatcher("mainManager.jsp").forward(request, response);
	}

	
}
