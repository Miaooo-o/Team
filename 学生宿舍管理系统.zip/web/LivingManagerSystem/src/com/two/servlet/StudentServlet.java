package com.two.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.two.bean.LivingManager;
import com.two.bean.Student;
import com.two.util.DbUtil;
import com.two.util.StringUtil;
import com.two.service.StudentService;
import com.two.service.impl.StudentServiceImpl;

@WebServlet("/student")
public class StudentServlet extends HttpServlet{


	private static final long serialVersionUID = 1L;

	StudentService studentService = new StudentServiceImpl();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		//当前用户类型
		Object currentUserType = session.getAttribute("currentUserType");
		//搜索框写入的数据
		String s_studentText = request.getParameter("s_studentText");
		String livingBuildId = request.getParameter("buildToSelect");
		//搜索类型
		String searchType = request.getParameter("searchType");
		
		
		String action = request.getParameter("action");
		Student student = new Student();
		if("preSave".equals(action)) {
			studentPreSave(request, response);
			return;
		} else if("save".equals(action)){
			studentSave(request, response);
			return;
		} else if("delete".equals(action)){
			studentDelete(request, response);
			return;
		} else
		if("list".equals(action)) {
			if(StringUtil.isNotEmpty(s_studentText)) {
				if("name".equals(searchType)) {
					student.setName(s_studentText);
				} else if("number".equals(searchType)) {
					student.setStuNumber(s_studentText);
				} else if("dorm".equals(searchType)) {
					student.setLivingName(s_studentText);
				}
			}
			if(StringUtil.isNotEmpty(livingBuildId)) {
				student.setLivingBuildId(Integer.parseInt(livingBuildId));
			}
			
			session.removeAttribute("s_studentText");
			session.removeAttribute("searchType");
			session.removeAttribute("buildToSelect");
			request.setAttribute("s_studentText", s_studentText);
			request.setAttribute("searchType", searchType);
			request.setAttribute("buildToSelect", livingBuildId);
			//搜索，根据不同数据搜索类型存入实体类中
		} else if("search".equals(action)){
			if(StringUtil.isNotEmpty(s_studentText)) {
				if("name".equals(searchType)) {
					student.setName(s_studentText);
				} else if("number".equals(searchType)) {
					student.setStuNumber(s_studentText);
				} else if("living".equals(searchType)) {
					student.setLivingName(s_studentText);
				}
				session.setAttribute("s_studentText", s_studentText);
				session.setAttribute("searchType", searchType);
			} else {
				session.removeAttribute("s_studentText");
				session.removeAttribute("searchType");
			}
			if(StringUtil.isNotEmpty(livingBuildId)) {
				student.setLivingBuildId(Integer.parseInt(livingBuildId));
				session.setAttribute("buildToSelect", livingBuildId);
			}else {
				session.removeAttribute("buildToSelect");
			}
		}
		Connection con = null;
		try {
			con=DbUtil.getConnection();
			if("admin".equals((String)currentUserType)) {
				//搜索：根据搜索类型查询
				List<Student> studentList = studentService.studentList(con, student);
				request.setAttribute("dormBuildList", studentService.livingBuildList(con));
				request.setAttribute("studentList", studentList);
				request.setAttribute("mainPage", "admin/student.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	private void studentDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String studentId = request.getParameter("studentId");
		Connection con = null;
		try {
			con = DbUtil.getConnection();
			studentService.studentDelete(con, studentId);
			request.getRequestDispatcher("student?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void studentSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String studentId = request.getParameter("studentId");
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		String livingBuildId = request.getParameter("livingBuildId");
		System.out.println(livingBuildId);
		String livingName = request.getParameter("livingName");
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String tel = request.getParameter("tel");
		System.out.println(studentId+userName+password+livingBuildId+livingName+name+sex+tel);
		int i =Integer.parseInt(livingBuildId);
		Student student = new Student(userName, password,i , livingName, name, sex, tel);
		if(StringUtil.isNotEmpty(studentId)) {
			student.setStudentId(Integer.parseInt(studentId));
		}
		Connection con = null;
		try {
			con = DbUtil.getConnection();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(studentId)) {
				saveNum = studentService.studentUpdate(con, student);
			} else if(studentService.haveNameByNumber(con, student.getStuNumber())){
				request.setAttribute("student", student);
				request.setAttribute("error", "有误");
				request.setAttribute("mainPage", "admin/studentSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
				try {
					DbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			} else {
				saveNum = studentService.studentAdd(con, student);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("student?action=list").forward(request, response);
			} else {
				request.setAttribute("student", student);
				request.setAttribute("error", "有误");
				request.setAttribute("mainPage", "admin/studentSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void studentPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String studentId = request.getParameter("studentId");
		Connection con = null;
		try {
			//
			con = DbUtil.getConnection();
			request.setAttribute("livingBuildList", studentService.livingBuildList(con));
			if (StringUtil.isNotEmpty(studentId)) {
				Student student = studentService.studentShow(con, studentId);
				System.out.println("student"+student);
				request.setAttribute("student", student);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("mainPage", "admin/studentSave.jsp");
		request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
	}

	
}
