package com.two.bean;

public class LivingBuild {/*宿舍楼层表*/
	private int livingBuildId;
	private String livingBuildName;
	private String livingBuilddetail;
	
	
	
	public LivingBuild() {
		super();
	}

	public LivingBuild(String livingBuildName,String livingBuilddetail) {
		this.livingBuildName = livingBuildName;
		this.livingBuilddetail = livingBuilddetail;
	}
	
	public int getLivingBuildId() {
		return livingBuildId;
	}
	public void setLivingBuildId(int livingBuildId) {
		this.livingBuildId = livingBuildId;
	}
	public String getLivingBuildName() {
		return livingBuildName;
	}
	public void setLivingBuildName(String livingBuildName) {
		this.livingBuildName = livingBuildName;
	}
	public String getLivingBuilddetail() {
		return livingBuilddetail;
	}
	public void setLivingBuilddetail(String livingBuilddetail) {
		this.livingBuilddetail = livingBuilddetail;
	}

	@Override
	public String toString() {
		return "LivingBuild [livingBuildId=" + livingBuildId
				+ ", livingBuildName=" + livingBuildName
				+ ", livingBuilddetail=" + livingBuilddetail + "]";
	}
	
	
	
}
