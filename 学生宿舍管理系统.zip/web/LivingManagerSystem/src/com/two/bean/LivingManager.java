package com.two.bean;

public class LivingManager {/*宿舍管理员表*/
	private int livingManagerId;
	private String userName;
	private String password;
	private int livingBuildId;
	private String livingBuildName;
	private String name;
	private String sex;
	private String tel;
	
	public LivingManager() {
		super();
	}

	public LivingManager(String userName, String password, String name,
			String sex, String tel) {
		super();
		this.userName = userName;
		this.password = password;
		this.name = name;
		this.sex = sex;
		this.tel = tel;
	}

	public LivingManager(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}

	public int getLivingManagerId() {
		return livingManagerId;
	}

	public void setLivingManagerId(int livingManagerId) {
		this.livingManagerId = livingManagerId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getLivingBuildId() {
		return livingBuildId;
	}

	public void setLivingBuildId(int livingBuildId) {
		this.livingBuildId = livingBuildId;
	}

	public String getLivingBuildName() {
		return livingBuildName;
	}

	public void setLivingBuildName(String livingBuildName) {
		this.livingBuildName = livingBuildName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	@Override
	public String toString() {
		return "LivingManager [livingManagerId=" + livingManagerId
				+ ", userName=" + userName + ", password=" + password
				+ ", livingBuildId=" + livingBuildId + ", livingBuildName="
				+ livingBuildName + ", name=" + name + ", sex=" + sex
				+ ", tel=" + tel + "]";
	}
	
	
	
	

}
