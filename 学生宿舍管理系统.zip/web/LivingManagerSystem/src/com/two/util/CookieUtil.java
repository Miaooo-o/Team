package com.two.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CookieUtil {
	//删除cookie操作
		public static void deleteCookie(String userName, HttpServletRequest request,
				HttpServletResponse response) {
			//如果得到类型与登录类型相匹配，直接讲cookie中的相关cookie进行删除
			Cookie[] cookies=request.getCookies();
			for(int i=0;cookies!=null && i<cookies.length;i++){
				if(cookies[i].getName().equals("livingUser")){
					if(userName.equals(userName=cookies[i].getValue().split("-")[0])) {
						Cookie cookie = new Cookie(cookies[i].getName(), null);
						cookie.setMaxAge(0);
						response.addCookie(cookie);
						break;
					}
				}
			}
			
		}

	//将用户名密码利用cookie的形式保存于客户端7天
		public static void rememberMe(String userName, String password, String userType,
				HttpServletResponse response) {
			Cookie user = new Cookie("livingUser", userName+"-"+password+"-"+userType+"-"+"yes");
			//存入客户端的时间
			user.setMaxAge(1*60*60*24*7);
			//相应到客户端   放入cookie中
			response.addCookie(user);
			
		}

	}

