package com.two.util;

public class PageUtil {
	
	public static int getValue() {
		int pageSize = 5;
		return pageSize;
	}
}
