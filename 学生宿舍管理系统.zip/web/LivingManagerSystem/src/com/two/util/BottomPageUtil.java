package com.two.util;

public class BottomPageUtil {
	
	public static String genPagation(int totalNum, int currentPage, int pageSize){
		//总页数
		int totalPage = totalNum%pageSize==0?totalNum/pageSize:totalNum/pageSize+1;
		
		StringBuffer pageCode = new StringBuffer();
		pageCode.append("<li><a href='livingManager?page=1'>首页</a></li>");
		//当等于第一页的时候 点击上一页不起作用
		if(currentPage==1) {
			pageCode.append("<li class='disabled'><a href='#'>上一页</a></li>");
		}else {
			//反之则可以
			pageCode.append("<li><a href='livingManager?page="+(currentPage-1)+"'>上一页</a></li>");
		}
		//数字显示
		for(int i=currentPage-2;i<=currentPage+2;i++) {
			if(i<1||i>totalPage) {
				continue;
			}
			if(i==currentPage) {
				pageCode.append("<li class='active'><a href='#'>"+i+"</a></li>");
			} else {
				pageCode.append("<li><a href='livingManager?page="+i+"'>"+i+"</a></li>");
			}
		}
		if(currentPage==totalPage) {
			pageCode.append("<li class='disabled'><a href='#'>下一页</a></li>");
		} else {
			pageCode.append("<li><a href='livingManager?page="+(currentPage+1)+"'>下一页</a></li>");
		}
		pageCode.append("<li><a href='livingManager?page="+totalPage+"'>最后一页</a></li>");
		return pageCode.toString();
	}
	
	public static String getPagBuild(int totalNum, int currentPage, int pageSize){
		int totalPage = totalNum%pageSize==0?totalNum/pageSize:totalNum/pageSize+1;
		StringBuffer pageCode = new StringBuffer();
		pageCode.append("<li><a href='livingBuild?page=1'>首页</a></li>");
		if(currentPage==1) {
			pageCode.append("<li class='disabled'><a href='#'>上一页</a></li>");
		}else {
			pageCode.append("<li><a href='livingBuild?page="+(currentPage-1)+"'>上一页</a></li>");
		}
		for(int i=currentPage-2;i<=currentPage+2;i++) {
			//当i小于1或大于总页数直接返回
			if(i<1||i>totalPage) {
				continue;
			}
			//等于当前页数时
			if(i==currentPage) {
				pageCode.append("<li class='active'><a href='#'>"+i+"</a></li>");
			} else {
				pageCode.append("<li><a href='livingBuild?page="+i+"'>"+i+"</a></li>");
			}
		}
		//判断是最后一页
		if(currentPage==totalPage) {
			pageCode.append("<li class='disabled'><a href='#'>下一页</a></li>");
		} else {
			pageCode.append("<li><a href='livingBuild?page="+(currentPage+1)+"'>下一页</a></li>");
		}
		pageCode.append("<li><a href='livingBuild?page="+totalPage+"'>最后一页</a></li>");
		return pageCode.toString();
	}

}
