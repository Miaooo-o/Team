package com.two.service;

public interface LoginService {
	
	public Object login(String userName,String password,String userType);

}
