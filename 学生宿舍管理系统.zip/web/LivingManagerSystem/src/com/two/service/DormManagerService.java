package com.two.service;

import java.util.List;

import com.two.bean.Record;
import com.two.bean.Student;

public interface DormManagerService {
	//获取楼的名字
	public String getBuildName(int buidId);

	//获取楼学生列表
	public List<Student> studentListWithBuild(int buildId);

	//获取楼缺勤记录
	public List<Record> recordListWithBuild(int buildId);
	
	//修改密码
	public void passwordUpdate(int livingManagerId, String newPassword);

	//获取缺勤记录
	public Record recordShow(String recordId);

	//根据学号和楼号查询学生信息
	public Student getNameById(String studentNumber, int buildId);

	//修改缺勤记录
	public int recordUpdate(Record record);

	//添加缺勤记录
	public int recordAdd(Record record);

	//删除缺勤记录
	public void recordDelete(String recordId);

	//查找
	public List<Student> studentSearch(String searchType,int buildId, String studentText);

	//缺勤记录查询
	public List<Record> studentRecordSearch(String searchType, int buildId, String studentText);
}
