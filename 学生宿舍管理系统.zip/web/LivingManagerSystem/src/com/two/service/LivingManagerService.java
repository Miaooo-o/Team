package com.two.service;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.two.bean.LivingManager;
import com.two.bean.PageBean;

public interface LivingManagerService {

	List<LivingManager> livingManagerList(Connection con, PageBean pageBean,
			LivingManager livingManager);

	int livingManagerCount(LivingManager livingManager);

	LivingManager dormManagerShow(Connection con, int livingManagerId);

	int livingManagerUpdate(Connection con, LivingManager livingManager);

	boolean haveManagerByUser(Connection con, String userName);

	int livingManagerAdd(Connection con, LivingManager livingManager);

	void livingManagerDelete(Connection con, int parseInt);


	

}
