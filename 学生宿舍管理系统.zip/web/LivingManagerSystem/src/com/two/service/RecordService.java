package com.two.service;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.two.bean.LivingBuild;
import com.two.bean.Record;

public interface RecordService {
	/*根据学号查缺勤记录*/
	List<Record> recordListWithNumber(Record s_record, String studentNumber) throws Exception;
	
	public List<Record> recordList(Connection co, Record record) throws Exception;

	List<LivingBuild> livingBuildList(Connection co);

	int recordDelete(Connection con, String recordId);
	
	
}
