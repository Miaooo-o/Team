package com.two.service;

import java.sql.Connection;

/*更新密码的业务层*/
public interface PasswordService {
	/*更新数据库的系统管理员密码*/
	public int adminUpdate(int adminId, String password)throws Exception;
	/*更新数据库的宿舍管理员密码*/
	public int managerUpdate(int managerId, String password)throws Exception;
	/*更新数据库的学生密码*/
	public int studentUpdate(int studentId, String password)throws Exception;
}
