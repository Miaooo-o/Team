package com.two.service;

import java.sql.Connection;
import java.util.List;

import com.two.bean.LivingBuild;
import com.two.bean.LivingManager;
import com.two.bean.PageBean;

public interface LivingBuildService {

	List<LivingBuild> livingBuildList(Connection con, PageBean pageBean,
			LivingBuild livingBuild);

	int livingBuildCount(Connection con, LivingBuild livingBuild);

	int livingBuildUpdate(Connection con, LivingBuild livingBuild);

	int livingBuildAdd(Connection con, LivingBuild livingBuild);

	LivingBuild livingBuildShow(Connection con, String livingBuildId);

	List<LivingManager> livingManWithBuildId(Connection con, String dormBuildId);

	List<LivingManager> livingManWithoutBuild(Connection con);

	boolean existManOrDormWithId(Connection con, String livingBuildId);

	int livingBuildDelete(Connection con, String livingBuildId);

	int managerUpdateWithId(Connection con, String livingBuildId,
			String livingManagerId);

}
