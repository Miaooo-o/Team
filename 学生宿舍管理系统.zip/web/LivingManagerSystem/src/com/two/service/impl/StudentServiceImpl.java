package com.two.service.impl;

import java.sql.Connection;
import java.util.List;

import com.two.bean.LivingBuild;
import com.two.bean.Student;
import com.two.dao.StudentDao;
import com.two.dao.impl.StudentDaoImpl;
import com.two.service.StudentService;

public class StudentServiceImpl implements StudentService {
	StudentDao studentDao = new StudentDaoImpl();

	@Override
	public List<Student> studentList(Connection con, Student student) {
		List<Student> list = studentDao.studentList(con,student);
		return list;
	}

	@Override
	public List<LivingBuild> livingBuildList(Connection con) {
		List<LivingBuild> list = studentDao.livingBuildList(con);
		return list;
	}

	@Override
	public Student studentShow(Connection con, String studentId) {
		Student student = studentDao.studentShow(con,studentId);
		return student;
	}

	@Override
	public int studentUpdate(Connection con, Student student) {
		int i= studentDao.studentUpdate(con,student);
		return i;
	}

	@Override
	public boolean haveNameByNumber(Connection con, String stuNumber) {
		boolean bool = studentDao.haveNameByNumber(con, stuNumber);
		return bool;
	}

	@Override
	public int studentAdd(Connection con, Student student) {
		int i = studentDao.studentAdd(con,student);
		return i;
	}

	@Override
	public int studentDelete(Connection con, String studentId) {
		studentDao.studentDelete(con, studentId);
		return 0;
	}

}
