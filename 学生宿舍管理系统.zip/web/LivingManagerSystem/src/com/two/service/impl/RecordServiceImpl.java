package com.two.service.impl;

import java.sql.Connection;
import java.util.List;

import com.two.util.DbUtil;
import com.two.bean.LivingBuild;
import com.two.bean.Record;
import com.two.dao.impl.RecordDaoImpl;
import com.two.service.RecordService;

public class RecordServiceImpl implements RecordService{

	DbUtil dbUtil = new DbUtil();
	RecordDaoImpl recored = new RecordDaoImpl();
	public List<Record> recordListWithNumber(Record s_record, String studentNumber) throws Exception
	{
        Connection conn = dbUtil.getCon();
        List<Record> recordList = null;
        try {
        	 recordList = recored.ListStudentRecord(conn, s_record, studentNumber);
        } catch (Exception ex) {
        	ex.printStackTrace();
        } finally {
        	dbUtil.closeCon(conn);
        }

		return recordList;
	}
	public List<Record> recordList(Connection co, Record record) throws Exception {
		
		return recored.recordList(co,record);
	}
	public List<LivingBuild> livingBuildList(Connection co) {
		
		return recored.livingBuildList(co);
	}
	@Override
	public int recordDelete(Connection con, String recordId) {
		return recored.recordDelete(con,recordId);
	}

}
