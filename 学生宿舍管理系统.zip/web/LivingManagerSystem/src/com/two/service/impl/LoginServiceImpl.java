package com.two.service.impl;

import java.sql.Connection;

import com.two.bean.Admin;
import com.two.bean.LivingManager;
import com.two.bean.Student;
import com.two.dao.LoginDao;
import com.two.dao.impl.LoginDaoImpl;
import com.two.service.LoginService;
import com.two.util.DbUtil;

public class LoginServiceImpl implements LoginService{
	
    private LoginDao ld = new LoginDaoImpl();
	@Override
	public Object login(String userName, String password, String userType) {
		DbUtil db = new DbUtil();
		Object object = null;
		Connection conn = null;
		try {
			conn = db.getConnection();
			//在业务层判断，登录类型，然后将账户密码带到dao层拿到整个对象的数据，类型不相同，所以统一以object类型返回到servlet层
			switch (userType) {
			case "admin":
				Admin admin = new Admin(userName,password);
				object = ld.AdminLogin(conn,admin);
				break;
			case "dormManager":
				LivingManager liv = new LivingManager(userName,password);
				object = ld.LivingManagerLogin(conn,liv);
				break;
			case "student":
				Student student = new Student(userName, password);
				object = ld.StudentLogin(conn, student);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return object;
	}

}
