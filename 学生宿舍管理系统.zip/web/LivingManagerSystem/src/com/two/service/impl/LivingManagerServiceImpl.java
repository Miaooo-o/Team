package com.two.service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.two.bean.LivingManager;
import com.two.bean.PageBean;
import com.two.dao.LivingManagerDao;
import com.two.dao.impl.LivingManagerDaoImpl;
import com.two.service.LivingManagerService;
import com.two.util.DbUtil;
import com.two.util.StringUtil;

public class LivingManagerServiceImpl implements LivingManagerService {
	
	private LivingManagerDao  livingManagerDao = new LivingManagerDaoImpl();

	@Override
	public List<LivingManager> livingManagerList(Connection con,PageBean pageBean, LivingManager livingManager) {
		List<LivingManager> list = livingManagerDao.livingManagerList(con,pageBean,livingManager);
		return list;
	}

	@Override
	public int livingManagerCount(LivingManager livingManager) {
		int totalcount  = livingManagerDao.livingManagerCount(livingManager);
		
		return totalcount;
	}

	@Override
	public LivingManager dormManagerShow(Connection con, int livingManagerId) {
		LivingManager livingManager =livingManagerDao.dormManagerShow(con, livingManagerId);
		return livingManager;
	}

	@Override
	public int livingManagerUpdate(Connection con, LivingManager livingManager) {
		
		return livingManagerDao.livingManagerUpdate(con,livingManager);
	}

	@Override
	public boolean haveManagerByUser(Connection con, String userName) {
		Boolean bool = livingManagerDao.haveManagerUser(con,userName);
		return bool;
	}

	@Override
	public int livingManagerAdd(Connection con, LivingManager livingManager) {
		
		return livingManagerDao.livingManagerAdd(con,livingManager);
	}

	@Override
	public void livingManagerDelete(Connection con, int parseInt) {
		livingManagerDao.livingManagerDelete(con, parseInt);
		
	}

	

}
