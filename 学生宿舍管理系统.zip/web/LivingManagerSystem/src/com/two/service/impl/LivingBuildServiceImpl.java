package com.two.service.impl;

import java.sql.Connection;
import java.util.List;

import com.two.bean.LivingBuild;
import com.two.bean.LivingManager;
import com.two.bean.PageBean;
import com.two.dao.LivingBuildDao;
import com.two.dao.impl.LivingBuilDaoImpl;
import com.two.service.LivingBuildService;

public class LivingBuildServiceImpl implements LivingBuildService {
    private LivingBuildDao livingBuildDao = new LivingBuilDaoImpl();
	@Override
	public List<LivingBuild> livingBuildList(Connection con, PageBean pageBean,
			LivingBuild livingBuild) {
		List<LivingBuild> list = livingBuildDao.livingBuildList(con,pageBean,livingBuild);
		return list;
	}

	@Override
	public int livingBuildCount(Connection con, LivingBuild livingBuild) {
		
		return livingBuildDao.livingBuildCount(con, livingBuild);
	}

	@Override
	public int livingBuildUpdate(Connection con, LivingBuild livingBuild) {
		
		return livingBuildDao.livingBuildUpdate(con,livingBuild);
	}

	@Override
	public int livingBuildAdd(Connection con, LivingBuild livingBuild) {
		
		return livingBuildDao.livingBuildAdd(con,livingBuild);
	}

	@Override
	public LivingBuild livingBuildShow(Connection con, String livingBuildId) {
		return livingBuildDao.livingBuildShow(con,livingBuildId);
	}

	@Override
	public List<LivingManager> livingManWithBuildId(Connection con,
			String livingBuildId) {
		
		return livingBuildDao.livingManWithBuildId(con,livingBuildId);
	}

	@Override
	public List<LivingManager> livingManWithoutBuild(Connection con) {
		
		return livingBuildDao.livingManWithoutBuild(con);
	}

	@Override
	public boolean existManOrDormWithId(Connection con, String livingBuildId) {
		return livingBuildDao.existManOrDormWithId(con,livingBuildId);
	}

	@Override
	public int  livingBuildDelete(Connection con, String livingBuildId) {
		
		return livingBuildDao.livingBuildDelete(con, livingBuildId);
	}

	@Override
	public int managerUpdateWithId(Connection con, String livingBuildId,
			String livingManagerId) {
		return livingBuildDao.managerUpdateWithId(con, livingBuildId,livingManagerId);
		
	}

}
