package com.two.service.impl;

import java.sql.Connection;

import com.two.dao.impl.PasswordDaoImpl;
import com.two.service.PasswordService;
import com.two.util.DbUtil;

public class PasswordServiceImpl implements PasswordService{

	DbUtil dbUtil = new DbUtil();
	PasswordDaoImpl passwordDaoImpl = new PasswordDaoImpl();
	@Override
	public int adminUpdate(int adminId, String password) throws Exception {
	    Connection conn = dbUtil.getCon();
	    int res = 0;
        try {
        	res = passwordDaoImpl.adminUpdateDao(conn, adminId, password);
        } catch (Exception ex) {
       	
        } finally {
        	dbUtil.closeCon(conn);
        }
		return res;
	}

	public int managerUpdate(int managerId, String password) throws Exception {
	    Connection conn = dbUtil.getCon();
	    int res = 0;
        try {
        	res = passwordDaoImpl.managerUpdateDao(conn, managerId, password);
        } catch (Exception ex) {
       	
        } finally {
        	dbUtil.closeCon(conn);
        }
		return res;

	}

	@Override
	public int studentUpdate(int studentId, String password) throws Exception {
	    Connection conn = dbUtil.getCon();
	    int res = 0;
        try {
        	res = passwordDaoImpl.studentUpdateDao(conn, studentId, password);
        } catch (Exception ex) {
       	
        } finally {
        	dbUtil.closeCon(conn);
        }
		return res;
	}

}
